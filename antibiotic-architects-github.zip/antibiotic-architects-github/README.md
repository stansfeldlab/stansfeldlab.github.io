# Antibiotic Architects

A game from the Stansfeld Research Group (University of Warwick). Players design antibiotic molecules from parts, test them in a molecular dynamics simulation, keep them away from the human version of the enzyme, and try to stay ahead of evolving bacteria. Players aged 9 and up can manage it, but it's aimed mainly at adults.

The whole game is one file, `Antibiotic-Architects.html`. It has no other files and needs no server code, so it runs anywhere that can serve a web page, including GitHub Pages.

## What's in this folder

| File | What it is |
|---|---|
| `Antibiotic-Architects.html` | The game. This is the only file the website needs. |
| `source/` | The editable source code and the build script that makes the game file. Only needed if you want to change the game. |
| `README.md` | This guide. |

## Option 1: add it to the lab website (recommended)

The lab website (stansfeldlab.github.io) already hosts its games as single HTML files in the top folder of the repository, for example `Superbug-Showdown.html`. Antibiotic Architects can go in the same place.

1. On GitHub, open the repository that builds stansfeldlab.github.io.
2. Choose **Add file → Upload files**, drag in `Antibiotic-Architects.html`, and choose **Commit changes**.
3. Wait a minute or two (progress shows in the repository's **Actions** tab). The game will then be at
   **https://stansfeldlab.github.io/Antibiotic-Architects.html**

To list it on the **Games & VR Demos** page, copy one of the existing game entries on that page and change its title, link and description, for example:

- Title: `Antibiotic Architects`
- Link: `Antibiotic-Architects.html`
- Description: `Design antibiotics and test them with molecular dynamics`

## Option 2: give it its own repository

1. Create a new public repository on GitHub, for example `antibiotic-architects`.
2. Upload `Antibiotic-Architects.html` and rename it to `index.html`. You can also upload `source/` if you want to keep the code with it.
3. In the repository, go to **Settings → Pages**. Under **Build and deployment**, set **Source** to **Deploy from a branch**, choose the `main` branch and the `/ (root)` folder, then choose **Save**.
4. After a minute or two the game will be at `https://<account-name>.github.io/antibiotic-architects/`.

If you host it anywhere other than `https://stansfeldlab.github.io/Antibiotic-Architects.html`, change the web address in the `canonical` and `og:url` lines near the top of the HTML file. Search engines and link previews use those lines.

## Using it at an outreach event

- **No internet needed once it has loaded.** Everything is inside the one file. You can also copy the file onto a laptop and double-click it to play with no connection at all.
- **Settings** (the cog at the top right) has full screen mode, sound on or off, an option to go back to the start screen when nobody has played for a while, **New player** (clears the stars) and **Clear the hall of fame**.
- **Stars and the hall of fame are saved only in that browser on that device.** Nothing is sent anywhere, and different devices keep separate scores.

## Changing the game

You need Python 3 to rebuild the game. No extra packages are needed.

1. Edit the files in `source/src/`:
   - `game.js`: everything the game does. Group details (name, website, the "About us" text) are in `CONFIG` near the top.
   - `missions.js`: the six main missions. `xmissions.js`: the five expert missions.
   - `body.html` and `head.html`: page text (including the science page) and styling.
   - `sim.js` and `gensim.js`: the simulations for the main and expert pockets.
2. Run `python3 source/build.py`. This rewrites `Antibiotic-Architects.html`.
3. Open the new file in a browser to check it, then upload it as above.

If you change a pocket or a mission's answer, check that the mission can still be solved. You'll need Node.js:

- Expert missions: `node source/xverify.js` runs every expert answer, and the designs each mission should reject, through the same simulation the game uses.
- Main missions: `node source/occ.js MOLECULE POCKET 12 500 3`, for example `node source/occ.js OOO OOO 12 500 3`, prints three repeat measurements of how long the molecule stays in the pocket (in %). A molecule passes at 70% or more and is safe for humans at 35% or less.

`table.txt` is a precomputed lookup table for the arms race. It covers every three-part molecule in every three-spot pocket, so don't edit it by hand.

## Licence

No licence is included yet. If you'd like other people to be able to reuse or adapt the game, add a `LICENSE` file to the repository. GitHub offers a picker for this under **Add file → Create new file**: type `LICENSE` as the name.
