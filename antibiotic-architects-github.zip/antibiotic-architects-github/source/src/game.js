'use strict';
/* =====================================================================
   CONFIG: edit these to personalise the game for your group / event
   ===================================================================== */
const CONFIG = {
  titleLine1: 'Antibiotic',
  titleLine2: 'Architects',
  groupName: 'Stansfeld Research Group',
  groupPlace: 'University of Warwick',
  groupTagline: 'Bringing Membrane Proteins to Life',
  groupWebsite: 'https://stansfeldlab.github.io/',
  aboutParagraphs: [
    'This game was made by the Stansfeld Research Group, a computational group at the University of Warwick in the School of Life Sciences and the Department of Chemistry, led by Phill Stansfeld.',
    'We use computer simulations, including molecular dynamics, together with AI structure prediction, to study membrane proteins: the proteins that sit in the oily membranes around every cell. That includes the proteins bacteria use to build their tough outer layers, and how bacteria resist last-line antibiotics such as polymyxins.',
    'We also help design new antimicrobials, so the challenges in this game are close to our real work. Come and ask us about it!'
  ],
  raceGenerations: 8,             // generations to survive in the arms race
  raceSpareTests: 3,              // failed tests allowed before the superbug wins
  soundOnByDefault: true,
  idleMinutesDefault: 0,          // 0 = never reset automatically
  timestepFs: 2,                  // MD timestep used in the "how long" calculator
  gpuNsPerDay: 400                // rough throughput of one modern GPU for a small solvated protein
};

/* ---------- utilities ---------- */
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const TAU = Math.PI * 2;
const reduceMotion = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
const STORE_PREFIX = 'antibiotic-architects:';   // unique, so other games on the same website can't clash with saved stars and scores
const store = {
  get(k, d) { try { const v = localStorage.getItem(STORE_PREFIX + k); return v == null ? d : JSON.parse(v); } catch (e) { return d; } },
  set(k, v) { try { localStorage.setItem(STORE_PREFIX + k, JSON.stringify(v)); } catch (e) { /* storage unavailable */ } }
};
function fitCanvas(cv) {
  const r = cv.getBoundingClientRect(), dpr = Math.min(2, window.devicePixelRatio || 1);
  const w = Math.max(1, Math.round(r.width * dpr)), h = Math.max(1, Math.round(r.height * dpr));
  if (cv.width !== w || cv.height !== h) { cv.width = w; cv.height = h; }
  const ctx = cv.getContext('2d'); ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  return { ctx, w: r.width, h: r.height };
}
function fmtTime(s) { s = Math.floor(s); return Math.floor(s / 60) + ':' + String(s % 60).padStart(2, '0'); }
function esc(s) { return String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])); }
function bigWords(x) {
  if (x < 1e6) return Math.round(x).toLocaleString('en-GB');
  const units = [[1e18, 'quintillion'], [1e15, 'quadrillion'], [1e12, 'trillion'], [1e9, 'billion'], [1e6, 'million']];
  for (const [u, w] of units) if (x >= u) { const v = x / u; return (v >= 100 ? Math.round(v) : v.toFixed(1).replace(/\.0$/, '')) + ' ' + w; }
}
const pick = a => a[Math.floor(Math.random() * a.length)];

/*@@SIM@@*/

/* ---------- pre-computed results table (same simulation, run offline) ---------- */
const TABLE = '@@TABLE@@';
const tIdx = s => TYPE_ORDER.indexOf(s[0]) * 16 + TYPE_ORDER.indexOf(s[1]) * 4 + TYPE_ORDER.indexOf(s[2]);
function predicted(mol, pocket) { const i = (tIdx(mol) * 64 + tIdx(pocket)) * 2; return +TABLE.substr(i, 2); }

/* ---------- chemistry ---------- */
const TYPES = {
  O: { name: 'Oily', group: 'methyl group', res: 'Leu', resFull: 'leucine', cls: 'O', sym: '', col: '#F5B041', dark: '#8A5A10', kind: 'oily' },
  P: { name: 'Water-loving', group: 'hydroxyl group (OH)', res: 'Ser', resFull: 'serine', cls: 'P', sym: '', col: '#5CC8D6', dark: '#1F5F69', kind: 'water-loving' },
  '+': { name: 'Positive', group: 'amine group (NH₃⁺)', res: 'Lys', resFull: 'lysine', cls: 'pos', sym: '+', col: '#7AA2FF', dark: '#2F4C8C', kind: 'positive' },
  '-': { name: 'Negative', group: 'carboxylate group (COO⁻)', res: 'Asp', resFull: 'aspartate', cls: 'neg', sym: '−', col: '#FF6B8B', dark: '#8C2F45', kind: 'negative' },
  R: { name: 'Ring', group: 'flat benzene ring, hangs below', res: 'Phe', resFull: 'phenylalanine', cls: 'R', sym: '', col: '#C9A2FF', dark: '#4A2C7D', kind: 'ring' },
  A: { name: 'Aromatic', group: 'flat ring', res: 'Phe', resFull: 'phenylalanine', cls: 'A', sym: '', col: '#C9A2FF', dark: '#4A2C7D', kind: 'flat-ring (aromatic)' }
};
const RESFULL = { Phe: 'phenylalanine', Trp: 'tryptophan', Tyr: 'tyrosine', Leu: 'leucine', Val: 'valine', Ile: 'isoleucine', Ala: 'alanine', Ser: 'serine', Thr: 'threonine', Lys: 'lysine', Arg: 'arginine', Asp: 'aspartate', Glu: 'glutamate' };
const HEX = '<svg viewBox="0 0 24 24"><path d="M12 1.8l8.8 5.1v10.2L12 22.2l-8.8-5.1V6.9z" fill="#4A2C7D" stroke="#C9A2FF" stroke-width="2.6" stroke-linejoin="round"/><circle cx="12" cy="12" r="4.6" fill="none" stroke="#C9A2FF" stroke-width="1.8"/></svg>';
const SPOTS = ['Left', 'Bottom', 'Right'];
const ico = t => `<i class="ico t-${TYPES[t].cls}" aria-hidden="true">${t === 'R' || t === 'A' ? HEX : TYPES[t].sym}</i>`;
const STICKS = {
  O: 'Oily spots, like leucine',
  P: 'Water-loving and charged spots, weakly (hydrogen bonds)',
  '+': 'Negative spots, like aspartate (a salt bridge)',
  '-': 'Positive spots, like lysine (a salt bridge)'
};
const BEND_TXT = {
  S: { label: 'straight', short: '–', svg: '<svg viewBox="0 0 40 24" aria-hidden="true"><path d="M4 12H36" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round"/><circle cx="20" cy="12" r="3.6" fill="currentColor"/></svg>' },
  L: { label: 'bend up', short: '↗', svg: '<svg viewBox="0 0 40 24" aria-hidden="true"><path d="M4 18H20L32 4" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/><circle cx="20" cy="18" r="3.6" fill="currentColor"/></svg>' },
  R: { label: 'bend down', short: '↘', svg: '<svg viewBox="0 0 40 24" aria-hidden="true"><path d="M4 6H20L32 20" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/><circle cx="20" cy="6" r="3.6" fill="currentColor"/></svg>' }
};
const XSTICKS = {   // the expert missions add rings
  O: 'Oily spots like leucine, and flat rings like phenylalanine',
  P: 'Water-loving and charged spots, weakly. Flat rings push it away',
  '+': 'Negative spots (a salt bridge), and flat rings like tryptophan (cation–\u2060π)',
  '-': 'Positive spots (a salt bridge). Flat rings push it away',
  R: 'Flat rings (π–\u2060π stacking), positive spots (cation–\u2060π) and oily spots. Only fits a deep spot'
};
const RULES = {
  amine: { label: 'Gets inside E. coli: has a positive amine group', test: d => d.includes('+'),
    hint: 'Add a positive part somewhere it won\'t spoil the fit. E. coli lets in molecules that carry a positive amine group.' },
  notTooOily: { label: 'Dissolves in blood: no more than two oily parts', test: d => d.filter(t => t === 'O').length <= 2,
    hint: 'Use no more than two oily parts, or the medicine won\'t dissolve in blood.' },
  greasy: { label: 'Dissolves in blood: no more than two greasy parts (oily parts and rings)', test: d => d.filter(t => t === 'O' || t === 'R').length <= 2,
    hint: 'Use no more than two greasy parts (oily parts and rings together), or the medicine won\'t dissolve in blood.' }
};

/* ---------- missions (pockets chosen and checked against the results table) ---------- */
/*@@MISSIONS@@*/

/* ---------- sound ---------- */
const Sound = {
  ctx: null, on: store.get('sound', CONFIG.soundOnByDefault),
  c() { if (!this.ctx) { const AC = window.AudioContext || window.webkitAudioContext; if (!AC) return null; this.ctx = new AC(); } if (this.ctx.state === 'suspended') this.ctx.resume(); return this.ctx; },
  tone(f, d = 0.15, type = 'sine', v = 0.07, when = 0) {
    if (!this.on) return; const c = this.c(); if (!c) return;
    const t = c.currentTime + when, o = c.createOscillator(), g = c.createGain();
    o.type = type; o.frequency.setValueAtTime(f, t);
    g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(v, t + 0.012); g.gain.exponentialRampToValueAtTime(0.0001, t + d);
    o.connect(g); g.connect(c.destination); o.start(t); o.stop(t + d + 0.03);
  },
  tick() { this.tone(720, 0.035, 'sine', 0.018); },
  place() { this.tone(523, 0.08, 'triangle', 0.05); },
  start() { [0, 7].forEach((s, i) => this.tone(392 * Math.pow(2, s / 12), 0.12, 'triangle', 0.05, i * 0.07)); },
  lose() { [0, -3].forEach((s, i) => this.tone(220 * Math.pow(2, s / 12), 0.22, 'sine', 0.06, i * 0.12)); },
  mutate() { [0, 1, 0, 1].forEach((s, i) => this.tone(180 + s * 40, 0.09, 'square', 0.025, i * 0.09)); },
  win() { [0, 4, 7, 12, 16].forEach((s, i) => this.tone(523.25 * Math.pow(2, s / 12), 0.42, 'triangle', 0.075, i * 0.085)); }
};
const Settings = { idle: store.get('idle', CONFIG.idleMinutesDefault) };

/* =====================================================================
   Drawing an enzyme pocket and the molecule inside it
   ===================================================================== */
let FONT = 'system-ui, sans-serif';
function hexPath(ctx, x, y, r) { ctx.beginPath(); for (let i = 0; i < 6; i++) { const a = Math.PI / 6 + i * Math.PI / 3; ctx[i ? 'lineTo' : 'moveTo'](x + r * Math.cos(a), y + r * Math.sin(a)); } ctx.closePath(); }
function drawPart(ctx, x, y, r, t, outline) {
  const T = TYPES[t];
  if (t === 'N') {   // the joint a ring hangs from
    ctx.fillStyle = '#EAF6F4'; ctx.beginPath(); ctx.arc(x, y, r * 0.42, 0, TAU); ctx.fill(); return;
  }
  if (t === 'R' || t === 'A') {   // flat aromatic ring
    const g = ctx.createRadialGradient(x - r * 0.3, y - r * 0.35, r * 0.1, x, y, r);
    g.addColorStop(0, t === 'R' ? '#8E67D0' : '#6A4AA3'); g.addColorStop(1, '#3A2264');
    hexPath(ctx, x, y, r); ctx.fillStyle = g; ctx.fill();
    ctx.lineJoin = 'round'; ctx.lineWidth = Math.max(2, r * 0.16); ctx.strokeStyle = T.col; ctx.stroke();
    ctx.lineWidth = Math.max(1.5, r * 0.1); ctx.beginPath(); ctx.arc(x, y, r * 0.42, 0, TAU); ctx.stroke();
    if (outline) { ctx.lineWidth = Math.max(2, r * 0.12); ctx.strokeStyle = '#EAF6F4'; hexPath(ctx, x, y, r + ctx.lineWidth * 0.8); ctx.stroke(); }
    return;
  }
  if (t === 'O') {
    const g = ctx.createRadialGradient(x - r * 0.35, y - r * 0.4, r * 0.08, x, y, r);
    g.addColorStop(0, '#FFE6AD'); g.addColorStop(0.55, '#F5B041'); g.addColorStop(1, '#B9750F');
    ctx.fillStyle = g; ctx.beginPath(); ctx.arc(x, y, r, 0, TAU); ctx.fill();
  } else if (t === 'P') {
    const lw = Math.max(2, r * 0.32);
    ctx.fillStyle = '#16465A'; ctx.beginPath(); ctx.arc(x, y, r, 0, TAU); ctx.fill();
    ctx.lineWidth = lw; ctx.strokeStyle = T.col; ctx.beginPath(); ctx.arc(x, y, r - lw / 2, 0, TAU); ctx.stroke();
  } else {
    ctx.fillStyle = T.dark; ctx.beginPath(); ctx.arc(x, y, r, 0, TAU); ctx.fill();
    const lw = Math.max(2, r * 0.22); ctx.lineWidth = lw; ctx.strokeStyle = T.col; ctx.beginPath(); ctx.arc(x, y, r - lw / 2, 0, TAU); ctx.stroke();
    ctx.fillStyle = '#F2F5FF'; ctx.font = `800 ${Math.round(r * 1.25)}px ${FONT}`; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.fillText(T.sym, x, y + r * 0.06);
  }
  if (outline) { ctx.lineWidth = Math.max(2, r * 0.14); ctx.strokeStyle = '#EAF6F4'; ctx.beginPath(); ctx.arc(x, y, r + ctx.lineWidth * 0.6, 0, TAU); ctx.stroke(); }
}
// world box shown in a panel: x -5.2..5.2, y -5.0..4.4 (expert pockets bring their own box)
const CLASSIC_BOX = { w: 10.4, top: 4.4, h: 9.4 };
function panelGeom(px0, py0, pw, ph, top = 44, bottom = 36, box = CLASSIC_BOX) {
  const avail = ph - top - bottom, s = Math.max(6, Math.min((pw - 24) / box.w, avail / box.h, 64)), off = Math.max(0, (avail - box.h * s) / 2);
  return { px0, py0, pw, ph, s, X0: px0 + pw / 2, Y0: py0 + top + off + box.top * s, box };
}
function smoothClosed(ctx, xs, ys) {
  const n = xs.length, mx = i => (xs[i] + xs[(i + 1) % n]) / 2, my = i => (ys[i] + ys[(i + 1) % n]) / 2;
  ctx.beginPath(); ctx.moveTo(mx(n - 1), my(n - 1));
  for (let i = 0; i < n; i++) ctx.quadraticCurveTo(xs[i], ys[i], mx(i), my(i));
  ctx.closePath();
}
function drawGenEnzyme(ctx, sim, P, o) {
  const s = P.s, SX = i => P.X0 + sim.x[i] * s, SY = i => P.Y0 - sim.y[i] * s, now = performance.now(), np = sim.np, N = sim.slots;
  if (o.title) {
    ctx.fillStyle = '#EAF6F4'; ctx.font = `700 ${Math.round(clamp(s * 0.42, 14, 19))}px ${FONT}`; ctx.textAlign = 'left'; ctx.textBaseline = 'top';
    ctx.fillText(o.title, P.px0 + 16, P.py0 + 16);
  }
  { // protein: every bead as an overlapping disc, so the surface follows the pocket's real shape
    const all = sim.surf.concat(sim.body);
    ctx.fillStyle = '#2A6283'; ctx.beginPath(); all.forEach(i => { ctx.moveTo(SX(i) + 0.9 * s, SY(i)); ctx.arc(SX(i), SY(i), 0.9 * s, 0, TAU); }); ctx.fill();
    ctx.fillStyle = '#1D4B66'; ctx.beginPath(); all.forEach(i => { ctx.moveTo(SX(i) + 0.76 * s, SY(i)); ctx.arc(SX(i), SY(i), 0.76 * s, 0, TAU); }); ctx.fill();
  }
  // deep spots waiting for a ring
  sim.pendPos.forEach((pp, k) => {
    if (!pp || sim.parts[k] === 'R') return;
    ctx.save(); ctx.setLineDash([4, 4]); ctx.lineWidth = 2; ctx.strokeStyle = 'rgba(201,162,255,0.55)';
    hexPath(ctx, P.X0 + pp[0] * s, P.Y0 - pp[1] * s, 0.6 * s); ctx.stroke(); ctx.restore();
  });
  // pocket spots, then their labels (pushed apart so they never overlap)
  const labs = [];
  for (let k = 0; k < N; k++) {
    const t = sim.type[k], site = sim.def.sites[k], from = sim.pendPos[k] || sim.dockPos[k];
    const flash = o.flashSpot === k && now - o.flashT < 4000;
    drawPart(ctx, SX(k), SY(k), 0.46 * s * sim.sigma[k], t, false);
    let dx = sim.native[k][0] - from[0], dy = sim.native[k][1] - from[1]; const m = Math.hypot(dx, dy) || 1; dx /= m; dy /= m;
    const L = 0.62 * sim.sigma[k] + 0.7;
    labs.push({ k, flash, x: P.X0 + (sim.native[k][0] + dx * L) * s, y: P.Y0 - (sim.native[k][1] + dy * L) * s, txt: (site.res || TYPES[t].res) + (TYPES[t].sym || '') });
  }
  if (o.labels !== false && s >= 16) {
    const fs = Math.round(clamp(s * 0.34, 11, 15)), hh = fs * 2.25;
    ctx.font = `700 ${fs}px ${FONT}`; labs.forEach(l => { l.w = ctx.measureText(l.txt).width + 10; });
    for (let it = 0; it < 30; it++) for (let a = 0; a < labs.length; a++) for (let b = a + 1; b < labs.length; b++) {
      const A = labs[a], B = labs[b], ox = (A.w + B.w) / 2 + 8 - Math.abs(A.x - B.x), oy = hh + 4 - Math.abs(A.y - B.y);
      if (ox > 0 && oy > 0) { const sg = A.x <= B.x ? 1 : -1; A.x -= sg * ox / 2; B.x += sg * ox / 2; }
    }
    labs.forEach(l => {
      ctx.fillStyle = 'rgba(11,34,51,0.72)'; ctx.beginPath();
      if (ctx.roundRect) ctx.roundRect(l.x - l.w / 2, l.y - hh / 2, l.w, hh, 6); else ctx.rect(l.x - l.w / 2, l.y - hh / 2, l.w, hh); ctx.fill();
      ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.fillStyle = 'rgba(168,197,204,0.9)'; ctx.font = `650 ${Math.round(fs * 0.78)}px ${FONT}`; ctx.fillText('spot ' + (l.k + 1), l.x, l.y - fs * 0.5);
      ctx.fillStyle = l.flash ? '#FF9A8F' : '#EAF6F4'; ctx.font = `700 ${fs}px ${FONT}`; ctx.fillText(l.txt, l.x, l.y + fs * 0.5);
    });
  }
  // who is sticking to whom (each part only pairs with its own spot)
  for (let a = 0; a < sim.nd; a++) {
    const i = np + a, ta = sim.type[i]; if (ta === 'N') continue;
    const k = a < N ? a : sim.ringOf[a - N][0], e = pairEpsX(ta, sim.type[k]), d = Math.hypot(sim.x[i] - sim.x[k], sim.y[i] - sim.y[k]);
    const dmax = 1.6 * (sim.sigma[i] + sim.sigma[k]) / 2; if (d > dmax || !e) continue; const al = clamp((dmax - d) / 0.5, 0, 1);
    ctx.save(); ctx.lineCap = 'round'; ctx.setLineDash([s * 0.12, s * 0.1]);
    ctx.strokeStyle = e >= 1.8 ? `rgba(225,200,255,${al})` : e > 0 ? `rgba(155,231,176,${0.9 * al})` : `rgba(255,122,107,${0.95 * al})`;
    ctx.lineWidth = Math.max(2, s * (0.06 + 0.05 * Math.abs(e)));
    ctx.beginPath(); ctx.moveTo(SX(i), SY(i)); ctx.lineTo(SX(k), SY(k)); ctx.stroke(); ctx.restore();
  }
  // the molecule: backbone, ring stalks, then the parts
  ctx.save(); ctx.strokeStyle = '#EAF6F4'; ctx.lineWidth = Math.max(3, s * 0.17); ctx.lineCap = ctx.lineJoin = 'round';
  ctx.beginPath(); for (let k = 0; k < N; k++) ctx[k ? 'lineTo' : 'moveTo'](SX(np + k), SY(np + k));
  sim.ringOf.forEach(([k, i]) => { ctx.moveTo(SX(np + k), SY(np + k)); ctx.lineTo(SX(i), SY(i)); });
  ctx.stroke(); ctx.restore();
  sim.ringOf.forEach(([, i]) => drawPart(ctx, SX(i), SY(i), 0.6 * s, 'R', true));
  for (let k = 0; k < N; k++) drawPart(ctx, SX(np + k), SY(np + k), 0.42 * s, sim.type[np + k], true);
  if (sim.grab) {
    const g = sim.grab, qx = P.X0 + g.x * s, qy = P.Y0 - g.y * s;
    ctx.save(); ctx.strokeStyle = 'rgba(234,246,244,0.8)'; ctx.lineWidth = 2; ctx.setLineDash([6, 5]);
    ctx.beginPath(); ctx.moveTo(SX(g.i), SY(g.i)); ctx.lineTo(qx, qy); ctx.stroke(); ctx.restore();
  }
  if (o.status) {
    const inside = sim.bound(), good = o.goodWhenBound !== false;
    ctx.fillStyle = inside ? (good ? '#9BE7B0' : '#FF9A8F') : '#A8C5CC';
    ctx.font = `650 ${Math.round(clamp(s * 0.36, 12, 16))}px ${FONT}`; ctx.textAlign = 'center'; ctx.textBaseline = 'alphabetic';
    ctx.fillText(inside ? 'Molecule is in the pocket' : 'Molecule is out of the pocket', P.X0, Math.min(P.py0 + P.ph - 12, P.Y0 + (P.box.h - P.box.top) * s + 24));
  }
}
function drawEnzyme(ctx, sim, P, o = {}) {
  if (sim.gen) return drawGenEnzyme(ctx, sim, P, o);
  const s = P.s, SX = i => P.X0 + sim.x[i] * s, SY = i => P.Y0 - sim.y[i] * s, now = performance.now();
  if (o.title) {
    ctx.fillStyle = '#EAF6F4'; ctx.font = `700 ${Math.round(clamp(s * 0.42, 14, 19))}px ${FONT}`; ctx.textAlign = 'left'; ctx.textBaseline = 'top';
    ctx.fillText(o.title, P.px0 + 16, P.py0 + 16);
  }
  // protein surface
  { // smooth closed outline through the protein beads
    const n = 26, mx = i => (SX(i) + SX((i + 1) % n)) / 2, my = i => (SY(i) + SY((i + 1) % n)) / 2;
    ctx.save(); ctx.lineCap = ctx.lineJoin = 'round'; ctx.beginPath(); ctx.moveTo(mx(n - 1), my(n - 1));
    for (let i = 0; i < n; i++) ctx.quadraticCurveTo(SX(i), SY(i), mx(i), my(i));
    ctx.closePath();
    ctx.strokeStyle = '#2A6283'; ctx.lineWidth = 1.72 * s; ctx.stroke();
    ctx.strokeStyle = '#1D4B66'; ctx.lineWidth = 1.42 * s; ctx.stroke();
    ctx.fillStyle = '#1D4B66'; ctx.fill(); ctx.restore();
  }
  // pocket spots and their labels
  LINING.forEach((i, k) => {
    const t = sim.type[i], nx = sim.native[i][0], ny = sim.native[i][1], m = Math.hypot(nx, ny);
    const flash = o.flashSpot === k && now - o.flashT < 4000;
    if (flash) {
      ctx.save(); ctx.strokeStyle = '#FF7A6B'; ctx.lineWidth = 3; ctx.globalAlpha = 0.5 + 0.5 * Math.abs(Math.sin(now / 220));
      ctx.beginPath(); ctx.arc(SX(i), SY(i), 0.75 * s, 0, TAU); ctx.stroke(); ctx.restore();
    }
    drawPart(ctx, SX(i), SY(i), 0.46 * s, t, false);
    if (o.labels !== false && s >= 16) {
      const f0 = (m + 0.62) / m, f1 = 4.15 / m, f2 = 4.62 / m;
      ctx.save(); ctx.strokeStyle = 'rgba(168,197,204,0.4)'; ctx.lineWidth = 1; ctx.setLineDash([2, 3]);
      ctx.beginPath(); ctx.moveTo(P.X0 + nx * f0 * s, P.Y0 - ny * f0 * s); ctx.lineTo(P.X0 + nx * f1 * s, P.Y0 - ny * f1 * s); ctx.stroke(); ctx.restore();
      ctx.fillStyle = flash ? '#FF9A8F' : '#C9DDE2'; ctx.font = `700 ${Math.round(clamp(s * 0.36, 12, 16))}px ${FONT}`; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.fillText(TYPES[t].res + (TYPES[t].sym ? ' ' + TYPES[t].sym : ''), P.X0 + nx * f2 * s, P.Y0 - ny * f2 * s);
    }
  });
  // who is sticking to whom
  for (let a = 0; a < 3; a++) LINING.forEach(i => {
    const e = pairEps(sim.type[26 + a], sim.type[i]), d = Math.hypot(sim.x[26 + a] - sim.x[i], sim.y[26 + a] - sim.y[i]);
    if (d > 1.75) return; const al = clamp((1.75 - d) / 0.55, 0, 1);
    ctx.save(); ctx.lineCap = 'round'; ctx.setLineDash([s * 0.12, s * 0.1]);
    ctx.strokeStyle = e > 0 ? `rgba(155,231,176,${0.9 * al})` : `rgba(255,122,107,${0.95 * al})`; ctx.lineWidth = Math.max(2, s * (0.06 + 0.05 * Math.abs(e)));
    ctx.beginPath(); ctx.moveTo(SX(26 + a), SY(26 + a)); ctx.lineTo(SX(i), SY(i)); ctx.stroke(); ctx.restore();
  });
  // the molecule
  ctx.save(); ctx.strokeStyle = '#EAF6F4'; ctx.lineWidth = Math.max(3, s * 0.17); ctx.lineCap = ctx.lineJoin = 'round';
  ctx.beginPath(); ctx.moveTo(SX(26), SY(26)); ctx.lineTo(SX(27), SY(27)); ctx.lineTo(SX(28), SY(28)); ctx.stroke(); ctx.restore();
  for (let i = 26; i < 29; i++) drawPart(ctx, SX(i), SY(i), 0.42 * s, sim.type[i], true);
  if (sim.grab) {
    const g = sim.grab, qx = P.X0 + g.x * s, qy = P.Y0 - g.y * s;
    ctx.save(); ctx.strokeStyle = 'rgba(234,246,244,0.8)'; ctx.lineWidth = 2; ctx.setLineDash([6, 5]);
    ctx.beginPath(); ctx.moveTo(SX(g.i), SY(g.i)); ctx.lineTo(qx, qy); ctx.stroke(); ctx.restore();
  }
  if (o.status) {
    const inside = sim.bound(), good = o.goodWhenBound !== false;
    ctx.fillStyle = inside ? (good ? '#9BE7B0' : '#FF9A8F') : '#A8C5CC';
    ctx.font = `650 ${Math.round(clamp(s * 0.36, 12, 16))}px ${FONT}`; ctx.textAlign = 'center'; ctx.textBaseline = 'alphabetic';
    ctx.fillText(inside ? 'Molecule is in the pocket' : 'Molecule is out of the pocket', P.X0, Math.min(P.py0 + P.ph - 12, P.Y0 + 5.0 * s + 24));
  }
}

/* =====================================================================
   Router
   ===================================================================== */
let current = 'home';
const enterHooks = {};
function go(name, push = true) {
  let screen = name;
  if (name === 'race') { Lab.openRace(); screen = 'lab'; }
  if (name === 'lab' && !Lab.mode) { name = screen = 'missions'; }
  if (!document.getElementById('screen-' + screen)) name = screen = 'home';
  current = screen;
  $$('.screen').forEach(s => s.classList.toggle('active', s.id === 'screen-' + screen));
  const navKey = screen === 'lab' ? (Lab.mode === 'race' ? 'race' : 'missions') : screen;
  $$('.mainnav button').forEach(b => { if (b.dataset.go === navKey) b.setAttribute('aria-current', 'page'); else b.removeAttribute('aria-current'); });
  const hash = '#' + (screen === 'lab' ? (Lab.mode === 'race' ? 'race' : 'lab') : name);
  if (push && location.hash !== hash) history.pushState(null, '', hash);
  if (enterHooks[screen]) enterHooks[screen]();
  $('#screen-' + screen).scrollTop = 0;
}
document.addEventListener('click', e => { const b = e.target.closest('[data-go]'); if (!b) return; e.preventDefault(); go(b.dataset.go); });
window.addEventListener('popstate', () => { const h = (location.hash || '#home').slice(1); if (h !== 'race') go(h, false); });

/* =====================================================================
   Home: a live simulation tells the story of resistance on a loop
   ===================================================================== */
const Hero = {
  sim: null, phase: 'hold', t: 0, outFor: 0, state: 0, flashT: -1e9,
  STATES: [{ pocket: '-OO', drug: '+OO' }, { pocket: '+OO', drug: '-OO' }],
  TEXT: {
    hold: ['An antibiotic is jammed in the pocket of a bacterial enzyme, so the bacteria can\'t grow.', '#9BE7B0'],
    mutate: ['The bacteria evolve. A mutation swaps one amino acid in the pocket…', '#FF7A6B'],
    escaped: ['…and the antibiotic no longer fits. The superbug survives.', '#FF7A6B'],
    redesign: ['Scientists redesign the antibiotic to fit the new pocket.', '#F5B041']
  },
  init() {
    this.sim = new PocketSim(); this.state = 0; this.apply(); this.sim.dock(); this.setPhase('hold');
  },
  apply() { const S = this.STATES[this.state]; this.sim.setPocket(S.pocket.split('')); this.sim.setDrug(S.drug.split('')); },
  setPhase(p) { this.phase = p; this.t = 0; this.outFor = 0; const [txt, col] = this.TEXT[p]; $('#heroStatus').textContent = txt; $('#heroDot').style.background = col; },
  tick(dt) {
    const sim = this.sim;
    if (!reduceMotion) {
      sim.step(40); this.t += dt;
      if (this.phase === 'hold' && this.t > 7) {
        this.state = 1 - this.state; const S = this.STATES[this.state]; sim.setPocket(S.pocket.split('')); this.flashT = performance.now(); this.setPhase('mutate');
      } else if (this.phase === 'mutate') {
        this.outFor = sim.rmsd() > 1.0 ? this.outFor + dt : 0;
        if (this.outFor > 0.5 || this.t > 8) this.setPhase('escaped');
      } else if (this.phase === 'escaped' && this.t > 2.5) {
        sim.setDrug(this.STATES[this.state].drug.split('')); sim.guide = 3; this.setPhase('redesign');
      } else if (this.phase === 'redesign') {
        if (sim.rmsd() < 0.4 || this.t > 6) { sim.guide = 0; if (this.t > 2) this.setPhase('hold'); }
      }
    }
    const cv = $('#heroCanvas'), { ctx, w, h } = fitCanvas(cv); ctx.clearRect(0, 0, w, h);
    const wide = w > 980, pw = wide ? Math.min(w * 0.5, h * 1.05) : w, ph = wide ? h * 0.9 : h;
    const P = panelGeom(wide ? w * 0.72 - pw / 2 : 0, wide ? (h - ph) / 2 : 0, pw, ph, wide ? 20 : 4);
    drawEnzyme(ctx, sim, P, { flashSpot: 0, flashT: this.flashT });
  }
};

/* =====================================================================
   Mission list
   ===================================================================== */
const progress = {
  data: store.get('progress', {}),
  get(k) { return this.data[k] || 0; },
  set(k, v) { if (v > this.get(k)) { this.data[k] = v; store.set('progress', this.data); } },
  clear() { this.data = {}; store.set('progress', {}); }
};
function starsText(k) { return '<span aria-hidden="true">' + '★'.repeat(k) + '<span class="off">' + '★'.repeat(3 - k) + '</span></span>'; }
function starsSVG(k) {
  return [0, 1, 2].map(i => `<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 2.6l2.9 6.1 6.6.8-4.9 4.6 1.3 6.6L12 17.4l-5.9 3.3 1.3-6.6-4.9-4.6 6.6-.8z" fill="${i < k ? '#F5B041' : 'none'}" stroke="${i < k ? '#F5B041' : '#2A6283'}" stroke-width="2" stroke-linejoin="round"/></svg>`).join('');
}
function renderMissions() {
  $('#missionList').innerHTML = ''; $('#expertList').innerHTML = '';
  const groups = [{ name: 'Getting started', text: 'Learn what sticks to what.', list: MISSIONS.slice(0, 3), root: '#missionList' },
                  { name: 'Fighting superbugs', text: 'Resistance, tough outer walls, and an enzyme that shreds antibiotics.', list: MISSIONS.slice(3), root: '#missionList' },
                  { name: 'Expert missions', text: 'Longer molecules that bend, ring parts that need a deep spot, and two new ways to stick: π–\u2060π stacking and cation–\u2060π. Best tried after the first six.', list: XMISSIONS, root: '#expertList', x: true }];
  groups.forEach(g => {
    const root = $(g.root), el = document.createElement('section'); el.className = 'lgroup' + (g.x ? ' expert' : '');
    el.innerHTML = `<h3>${esc(g.name)}</h3><p class="small">${esc(g.text)}</p><div class="strand"><svg aria-hidden="true"><path fill="none" stroke="#2A6283" stroke-width="10" stroke-linecap="round" stroke-linejoin="round"/></svg></div>`;
    g.list.forEach(M => {
      const st = progress.get(M.key), num = (g.x ? 'E' : '') + ((g.x ? XMISSIONS : MISSIONS).indexOf(M) + 1), b = document.createElement('button');
      b.className = 'lvl'; b.setAttribute('aria-label', `${g.x ? 'Expert mission ' + num.slice(1) : 'Mission ' + num}: ${M.name}, ${M.target}, ${st} of 3 stars`);
      b.innerHTML = `<span class="lvl-bead ${st === 3 ? 'done' : st ? 'part' : ''}">${num}</span><span class="lvl-name">${esc(M.name)}</span><span class="lvl-sub">${esc(M.target)}</span><span class="stars-txt">${starsText(st)}</span>`;
      b.addEventListener('click', () => { Lab.openMission(M); go('lab'); });
      $('.strand', el).appendChild(b);
    });
    root.appendChild(el);
  });
  $('#raceGensTxt').textContent = CONFIG.raceGenerations;
  const best = Fame.best(); $('#raceBest').textContent = best ? `Best so far: ${best.name}, ${best.gens} generation${best.gens === 1 ? '' : 's'} with ${best.tests} tests.` : '';
  layoutStrands();
}
function layoutStrands() {
  $$('.strand').forEach(strand => {
    const nodes = $$('.lvl', strand), W = strand.clientWidth; if (!W) return;
    const cols = clamp(Math.floor(W / 175), 2, 3), colW = W / cols, rowH = 182, rows = Math.ceil(nodes.length / cols), pts = [];
    strand.style.height = rows * rowH + 'px';
    nodes.forEach((nd, k) => {
      const r = Math.floor(k / cols); let c = k % cols; if (r % 2) c = cols - 1 - c;
      const x = colW * (c + 0.5), y = r * rowH + 40; nd.style.left = (x - 80) + 'px'; nd.style.top = (y - 36) + 'px'; pts.push([x, y]);
    });
    // between rows, run down the outside edge so the line never crosses a mission's name
    let d = pts.length ? `M${pts[0][0].toFixed(1)} ${pts[0][1].toFixed(1)}` : '';
    for (let i = 1; i < pts.length; i++) {
      const [x0, y0] = pts[i - 1], [x1, y1] = pts[i];
      if (Math.abs(y1 - y0) < 1) { d += ` L${x1.toFixed(1)} ${y1.toFixed(1)}`; continue; }
      const out = x0 > W / 2 ? clamp(x0 + 92, 6, W - 6) : clamp(x0 - 92, 6, W - 6);
      d += ` L${out.toFixed(1)} ${y0.toFixed(1)} L${out.toFixed(1)} ${y1.toFixed(1)} L${x1.toFixed(1)} ${y1.toFixed(1)}`;
    }
    $('path', strand).setAttribute('d', d);
  });
}
enterHooks.missions = () => renderMissions();
window.addEventListener('resize', () => { if (current === 'missions') layoutStrands(); if (current === 'lab' && Lab.X && Lab.X.bendable) Lab.drawShape(); });

/* =====================================================================
   The lab: design a molecule, test it with MD, respond to evolution
   ===================================================================== */
const Lab = {
  mode: null, M: null, X: null, stage: 0, bact: 'OOO', human: null, rules: [], parts: TYPE_ORDER,
  drug: ['P', 'P', 'P'], bends: [], sel: 0, tests: 0, history: [], phase: 'design', last: null, assay: null,
  reps: null, panels: [], grab: null, flash: { spot: -1, t: -1e9 }, note: '', race: null, after: null, frame: 0,

  init() {
    this.classicReps = { bact: Array.from({ length: SIM.replicas }, () => new PocketSim()), human: Array.from({ length: SIM.replicas }, () => new PocketSim()) };
    this.reps = this.classicReps;
    $('#testBtn').addEventListener('click', () => this.test(true));
    $('#labBack').addEventListener('click', () => go(this.mode === 'race' ? 'home' : 'missions'));
    $('#cheat').innerHTML = TYPE_ORDER.map(t => `<tr><td>${ico(t)} ${TYPES[t].name}</td><td>${STICKS[t]}</td></tr>`).join('');
    this.bindCanvas();
  },
  sims(side) { return this.reps[side]; },
  shown(side) { return this.reps[side][0]; },

  /* ----- set up a mission or a race ----- */
  openMission(M) {
    this.cancel(); this.mode = 'mission'; this.M = M; this.stage = 0; this.race = null;
    if (M.expert) this.setupX(M); else this.setup(M.bact, M.human, M.rules || [], M.parts);
    this.render();
  },
  list() { return this.M && this.M.expert ? XMISSIONS : MISSIONS; },
  par() { return this.X ? 2 : this.M && this.M.mutation ? 2 : 1; },   // tests allowed for three stars
  spot(k) { return this.X ? 'Spot ' + (k + 1) : SPOTS[k]; },
  sides() { return this.human ? ['bact', 'human'] : ['bact']; },
  // expert missions: a freshly built pocket for each enzyme, longer molecules, bends and rings
  setupX(M) {
    const N = M.bact.sites.length, def = pk => ({ scale: M.scale, bends: pk.bends.split(''), sites: pk.sites });
    this.X = M; this.bact = M.bact; this.human = M.human; this.rules = M.rules || []; this.parts = M.parts;
    this.reps = { bact: Array.from({ length: SIM.replicas }, () => new GenPocketSim(def(M.bact))), human: M.human ? Array.from({ length: SIM.replicas }, () => new GenPocketSim(def(M.human))) : [] };
    this.drug = Array(N).fill('P'); this.bends = M.bendable ? Array(N - 2).fill('S') : M.bact.bends.split('');
    this.sel = 0; this.tests = 0; this.history = []; this.phase = 'design'; this.last = null; this.assay = null; this.after = null;
    this.flash = { spot: -1, t: -1e9 }; this.mutation = null; this.note = ''; this.evoStep = null;
    this.applyDrug(); this.redock();
  },
  applyDrug() { this.sides().forEach(side => this.reps[side].forEach(s => this.X ? s.setDrug(this.drug, this.bends) : s.setDrug(this.drug))); },
  setBend(j) {
    if (this.busy()) return;
    const order = ['S', 'L', 'R']; this.bends[j] = order[(order.indexOf(this.bends[j]) + 1) % 3];
    this.applyDrug(); this.redock(); Sound.place();
    if (this.phase === 'result') this.phase = 'design';
    this.renderBench(); this.renderGoals();
  },
  openRace() {
    if (this.mode === 'race' && this.race && !this.race.over) { this.render(); return; }
    this.startRace();
  },
  startRace() {
    this.cancel(); this.mode = 'race'; this.M = null; this.stage = 0;
    const H = pick(RACE_HUMANS), all = raceStates(H), comp = { O: 'O', P: 'P', '+': '-', '-': '+' };
    const easy = all.filter(b => { const n = b.split('').map(c => comp[c]).join(''); return predicted(n, b) >= RACE_SOLVE.bact && predicted(n, H) <= RACE_SOLVE.human; });
    const starts = easy.length ? easy : all;
    this.race = { gen: 1, spare: CONFIG.raceSpareTests, tests: 0, t0: null, recent: [], over: false, won: false, famed: false };
    const b = pick(starts); this.race.recent.push(b);
    this.setup(b, H, [], TYPE_ORDER);
    this.render();
  },
  setup(bact, human, rules, parts) {
    this.X = null; this.reps = this.classicReps; this.bends = [];
    this.bact = bact; this.human = human; this.rules = rules; this.parts = parts;
    this.drug = ['P', 'P', 'P']; this.sel = 0; this.tests = 0; this.history = []; this.phase = 'design'; this.last = null; this.assay = null; this.after = null;
    this.flash = { spot: -1, t: -1e9 }; this.mutation = null; this.note = ''; this.evoStep = null;
    ['bact', 'human'].forEach(side => this.reps[side].forEach(s => { s.setPocket((side === 'bact' ? bact : (human || 'PPP')).split('')); s.setDrug(this.drug); }));
    this.redock();
  },
  redock() { ['bact', 'human'].forEach(side => { const s = this.shown(side); if (s) { s.reset(); s.dock(); } }); },
  cancel() { this.assay = null; clearTimeout(this.timer); this.onUp(); },
  setDrugPart(k, t) {
    if (this.busy()) return;
    this.drug[k] = t; if (this.X) this.applyDrug(); else ['bact', 'human'].forEach(side => this.reps[side].forEach(s => s.setDrug(this.drug)));
    this.redock(); Sound.place(); this.sel = Math.min(this.drug.length - 1, k + 1);
    if (this.phase === 'result') this.phase = 'design';
    this.renderBench(); this.renderGoals();
  },
  setPocket(side, pk) { this[side] = pk; this.reps[side].forEach(s => s.setPocket(pk.split(''))); },
  busy() { return !!this.assay || ['evolving', 'done', 'over'].includes(this.phase); },

  /* ----- the test: 8 replicas of each enzyme, pooled ----- */
  test(counted, onDone) {
    if (this.assay) return;
    if (counted && this.busy()) return;
    this.onUp();
    const frames = Math.round(SIM.T / (160 * SIM.dt)), sides = this.human ? ['bact', 'human'] : ['bact'];
    sides.forEach(side => this.reps[side].forEach(s => { s.reset(); s.dock(); }));
    const code = {}; sides.forEach(side => code[side] = Array.from({ length: SIM.replicas }, () => new Uint8Array(frames)));
    this.assay = { f: 0, frames, sides, code, inside: { bact: 0, human: 0 }, counted, onDone, drug: this.drug.join(''), bends: this.bends.join('') };
    if (counted) { this.note = ''; this.tests++; if (this.race) { this.race.tests++; if (this.race.t0 == null) this.race.t0 = performance.now(); } }
    Sound.start(); this.buildResults(); this.renderBench(); this.renderGoals();
    if (window.innerWidth <= 860 && current === 'lab') $('#screen-lab').scrollTo({ top: 0, behavior: reduceMotion ? 'auto' : 'smooth' });
    $('#prog').hidden = false; this.setNote(`Simulating ${SIM.replicas} copies of each enzyme…`);
  },
  stepAssay() {
    const a = this.assay;
    a.sides.forEach(side => this.reps[side].forEach((s, r) => { s.step(160); const b = s.bound() ? 1 : 0; a.code[side][r][a.f] = b; a.inside[side] += b; }));
    a.f++;
    $('#prog i').style.width = (100 * a.f / a.frames).toFixed(1) + '%';
    if (a.f % 4 === 0 || a.f >= a.frames) this.updateResults(false);
    if (a.f >= a.frames) this.finishAssay();
  },
  finishAssay() {
    const a = this.assay, n = a.frames * SIM.replicas;
    const res = { drug: a.drug, bends: a.bends, bact: Math.round(100 * a.inside.bact / n), human: a.sides.includes('human') ? Math.round(100 * a.inside.human / n) : null, pocket: this.bact, humanPocket: this.human };
    res.blocked = res.bact >= SIM.passBact;
    res.safe = res.human == null || res.human <= SIM.passHuman;
    res.rules = this.rules.map(k => ({ key: k, ok: RULES[k].test(a.drug.split('')) }));
    res.pass = res.blocked && res.safe && res.rules.every(r => r.ok);
    res.counted = a.counted;
    this.last = { res, code: a.code, frames: a.frames }; this.assay = null;
    $('#prog').hidden = true; this.setNote('');
    if (a.counted) { this.history.unshift(res); this.history.length = Math.min(this.history.length, 8); }
    this.updateResults(true);
    if (a.onDone) a.onDone(res); else this.afterTest(res);
    this.render();
    const target = $('#stageBox').children.length ? $('#stageBox') : $('#results');
    if (target && target.scrollIntoView) target.scrollIntoView({ behavior: reduceMotion ? 'auto' : 'smooth', block: 'nearest' });
  },
  afterTest(res) {
    if (this.mode === 'mission') {
      if (!res.pass) { Sound.lose(); this.phase = 'result'; return; }
      Sound.win();
      if (this.M.mutation && this.stage === 0) { this.phase = 'stagewin'; return; }
      this.phase = 'done';
      const stages = this.par(), stars = this.tests <= stages ? 3 : this.tests <= stages + 2 ? 2 : 1;
      this.starsWon = stars; progress.set(this.M.key, stars);
    } else {
      const R = this.race;
      if (!res.pass) {
        Sound.lose();
        if (R.spare <= 0) { this.raceOver(false); return; }
        R.spare--; this.phase = 'result'; return;
      }
      Sound.win();
      if (R.gen >= CONFIG.raceGenerations) { this.raceOver(true); return; }
      this.phase = 'evolving'; this.evoStep = 'waiting'; this.timer = setTimeout(() => this.evolveRace(), 1800);
    }
  },

  /* ----- evolution ----- */
  evolveMission() {
    const mu = this.M.mutation, pk = this.bact.split(''); pk[mu.spot] = mu.to;
    this.mutate(mu.spot, pk.join(''));
    this.timer = setTimeout(() => this.test(false, res => {
      this.stage = 1; this.phase = 'design';
      if (res.pass) this.note = 'Your molecule still works against the mutant this time, but the bacteria are catching up. Redesign it to fit the new pocket properly.';
    }), 1600);
  },
  evolveRace(retry) {
    const R = this.race, H = this.human, cur = this.drug.join(''), b = this.bact, opts = [], fallback = [];
    for (let k = 0; k < 3; k++) for (const t of TYPE_ORDER) {
      if (t === b[k]) continue;
      const nb = b.slice(0, k) + t + b.slice(k + 1);
      if (!raceOK(nb, H) || R.recent.includes(nb)) continue;
      fallback.push([predicted(cur, nb), k, nb]);
      if (predicted(cur, nb) <= 45) opts.push([k, nb]);
    }
    let k, nb;
    if (opts.length) [k, nb] = pick(opts);
    else if (fallback.length) { fallback.sort((x, y) => x[0] - y[0]); [, k, nb] = fallback[0]; }
    else if (!retry) { R.recent = []; return this.evolveRace(true); }
    else { this.phase = 'design'; this.note = 'The bacteria couldn\'t find a way to escape your molecule this time!'; R.gen++; if (R.gen > CONFIG.raceGenerations) this.raceOver(true); this.render(); return; }
    R.recent.push(nb); if (R.recent.length > 3) R.recent.shift();
    this.mutate(k, nb); R.gen++;
    this.timer = setTimeout(() => this.test(false, res => {
      if (res.pass) {
        this.note = 'Lucky! Your molecule still works against this mutant. The bacteria will try again.';
        if (R.gen >= CONFIG.raceGenerations) { this.raceOver(true); return; }
        this.phase = 'evolving'; this.evoStep = 'waiting'; this.timer = setTimeout(() => this.evolveRace(), 2200);
      } else this.phase = 'design';
    }), 1600);
  },
  mutate(spot, newPocket) {
    const from = this.bact[spot], to = newPocket[spot];
    this.setPocket('bact', newPocket); this.flash = { spot, t: performance.now() };
    this.mutation = { spot, from, to }; this.phase = 'evolving'; this.evoStep = 'mutated'; this.note = '';
    Sound.mutate(); this.setNote(`Mutation! ${TYPES[from].res} → ${TYPES[to].res} at the ${SPOTS[spot].toLowerCase()} spot`);
    this.render();
    setTimeout(() => { const c = $(`#pmap .chip[data-row="bact"][data-k="${spot}"]`); if (c) c.classList.add('flash'); }, 30);
  },
  raceOver(won) {
    const R = this.race; R.over = true; R.won = won; R.time = R.t0 ? (performance.now() - R.t0) / 1000 : 0;
    R.survived = won ? CONFIG.raceGenerations : R.gen - 1; this.phase = 'over';
    if (won) Sound.win();
  },

  /* ----- rendering the side panel ----- */
  render() {
    const race = this.mode === 'race', M = this.M;
    $('#labBack').textContent = race ? 'Start screen' : 'All missions';
    if (race) {
      $('#labMeta').textContent = `Survive ${CONFIG.raceGenerations} generations`;
      $('#labTitle').textContent = 'Superbug arms race';
      $('#labBrief').textContent = this.race.over ? (this.race.won ? 'You kept the superbug in check for every generation. Can you do it in fewer tests?' : 'The bacteria evolved faster than you could keep up. Have another go!')
        : this.race.gen === 1 && !this.tests ? 'Block the bacterial enzyme without touching the human one. Every time you succeed, the bacteria evolve a new pocket. A failed test uses up a spare test: run out, and the superbug wins.'
        : 'The bacteria have evolved. Look at what changed in their pocket, then redesign your molecule.';
      $('#labFact').innerHTML = '<strong>Real world:</strong> bacteria can only change their pocket in ways that keep their enzyme working. In this game they can\'t make it entirely water-loving.';
    } else {
      $('#labMeta').textContent = `${M.expert ? 'Expert mission' : 'Mission'} ${this.list().indexOf(M) + 1} of ${this.list().length}: ${M.target}`;
      $('#labTitle').textContent = M.name;
      $('#labBrief').textContent = this.stage ? M.mutation.brief : M.brief;
      $('#labFact').innerHTML = M.fact;
    }
    $('#stage').classList.toggle('two', !!this.human);
    const ST = this.X ? XSTICKS : STICKS;
    $('#cheat').innerHTML = Object.keys(ST).filter(t => this.parts.includes(t)).map(t => `<tr><td>${ico(t)} ${TYPES[t].name}</td><td>${ST[t]}</td></tr>`).join('');
    $('#howto').textContent = this.X ? (this.X.bendable ? 'Tap a spot on your molecule, then pick a part. Tap the joints underneath to bend the molecule so its shape matches the pocket.' : 'Tap a spot on your molecule, then pick a part. Ring parts hang below the molecule, so they need a deep spot.')
      : 'Tap a spot on your molecule, then pick a part for it. Each spot sits next to the amino acid above it.';
    this.renderHud(); this.renderGoals(); this.renderBench(); this.renderStageBox(); this.renderNotebook();
    if (this.last && !this.assay) { if (!$('#results .res')) this.buildResults(true); this.updateResults(true); }
    else if (!this.assay) $('#results').innerHTML = '';
  },
  renderHud() {
    const hud = $('#raceHud'), R = this.race;
    if (!R) { hud.hidden = true; return; }
    hud.hidden = false;
    const flask = full => `<svg viewBox="0 0 18 20" aria-hidden="true"><path d="M6 1h6M7 1v6L2 17a1.5 1.5 0 0 0 1.3 2h11.4A1.5 1.5 0 0 0 16 17L11 7V1" fill="${full ? '#F5B041' : 'none'}" stroke="${full ? '#F5B041' : '#2A6283'}" stroke-width="1.8" stroke-linejoin="round"/></svg>`;
    hud.innerHTML = `<span class="lbl">Generation ${Math.min(R.gen, CONFIG.raceGenerations)} of ${CONFIG.raceGenerations}</span>
      <span class="gens" aria-hidden="true">${Array.from({ length: CONFIG.raceGenerations }, (_, i) => `<span class="g ${i < (R.over ? R.survived : R.gen - 1) ? 'done' : i === R.gen - 1 && !R.over ? 'now' : ''}"></span>`).join('')}</span>
      <span>Spare tests <span class="flasks" role="img" aria-label="${R.spare} spare tests">${Array.from({ length: CONFIG.raceSpareTests }, (_, i) => flask(i < R.spare)).join('')}</span></span>
      <span>Tests used <span class="stat">${R.tests}</span></span>
      ${this.mutation && !R.over ? `<span class="lbl mut">Latest mutation: ${TYPES[this.mutation.from].res} → ${TYPES[this.mutation.to].res} at the ${SPOTS[this.mutation.spot].toLowerCase()} spot</span>` : ''}`;
  },
  renderGoals() {
    const L = this.last && this.last.res, fresh = L && L.drug === this.drug.join('') && (L.bends || '') === this.bends.join('') && L.pocket === this.bact && !this.assay;
    const item = (state, txt) => `<li class="${state}"><span class="mk" aria-hidden="true">${state === 'ok' ? '✓' : state === 'bad' ? '✕' : ''}</span><span>${txt}${state ? `<span class="sr">: ${state === 'ok' ? 'done' : 'not yet'}</span>` : ''}</span></li>`;
    let h = item(fresh ? (L.blocked ? 'ok' : 'bad') : '', `Stays in the <strong>bacterial</strong> pocket at least ${SIM.passBact}% of the time`);
    if (this.human) h += item(fresh ? (L.safe ? 'ok' : 'bad') : '', `Stays in the <strong>human</strong> pocket no more than ${SIM.passHuman}% of the time`);
    this.rules.forEach(k => { h += item(RULES[k].test(this.drug) ? 'ok' : 'bad', RULES[k].label); });
    if (this.mode === 'mission') h += `<li class="tests">Tests used: ${this.tests}. Solve it in ${this.par()} for three stars.</li>`;
    $('#goals').innerHTML = h;
  },
  renderBench() {
    if (this.X) return this.renderBenchX();
    $('#pmap').style.gridTemplateColumns = ''; $('#pmap').classList.remove('x', 'n5'); $('#shapeWrap').hidden = true;
    const busy = this.busy(), H = this.human;
    let h = '<span></span>' + SPOTS.map(s => `<span class="hd">${s}</span>`).join('');
    const chips = (row, pk) => pk.split('').map((t, k) => `<span class="chip ${row === 'human' && H[k] !== this.bact[k] ? 'diff' : ''}" data-row="${row}" data-k="${k}" aria-label="${SPOTS[k]} spot: ${TYPES[t].resFull}, ${TYPES[t].kind}">${ico(t)}${TYPES[t].res}</span>`).join('');
    h += `<span class="rl">Bacteria</span>${chips('bact', this.bact)}`;
    if (H) h += `<span class="rl">Human</span>${chips('human', H)}`;
    h += '<span class="rl">Your molecule</span>' + this.drug.map((t, k) =>
      `<button type="button" class="slot" data-k="${k}" aria-pressed="${k === this.sel}" ${busy ? 'disabled' : ''} aria-label="${SPOTS[k]} part of your molecule: ${TYPES[t].name.toLowerCase()}. Select to change it.">${ico(t)}</button>`).join('');
    $('#pmap').innerHTML = h;
    $$('#pmap .slot').forEach(b => b.addEventListener('click', () => { this.sel = +b.dataset.k; Sound.tick(); this.renderBench(); $(`#pmap .slot[data-k="${this.sel}"]`).focus(); }));
    this.benchTail(busy);
  },
  benchTail(busy) {
    $('#palette').innerHTML = this.parts.map(t => `<button type="button" class="pbtn" data-t="${t}" ${busy ? 'disabled' : ''}>${ico(t)}<span><b>${TYPES[t].name}</b><small>${TYPES[t].group}</small></span></button>`).join('');
    $$('#palette .pbtn').forEach(b => b.addEventListener('click', () => this.setDrugPart(this.sel, b.dataset.t)));
    const tb = $('#testBtn'); tb.disabled = busy; tb.textContent = this.assay ? 'Simulating…' : 'Test in a simulation';
    $('#benchWrap').hidden = this.phase === 'over';
  },
  renderBenchX() {
    const busy = this.busy(), M = this.X, N = this.drug.length, B = M.bact.sites, H = M.human && M.human.sites, pm = $('#pmap');
    pm.style.gridTemplateColumns = `auto repeat(${N}, minmax(0, 1fr))`; pm.classList.add('x'); pm.classList.toggle('n5', N >= 5);
    const diff = (a, b) => a.t !== b.t || !!a.deep !== !!b.deep;
    const chip = (row, st, k) => `<span class="chip ${st.deep ? 'deep' : ''} ${row === 'human' && diff(st, B[k]) ? 'diff' : ''}" data-row="${row}" data-k="${k}" aria-label="Spot ${k + 1}: ${RESFULL[st.res] || TYPES[st.t].resFull}, ${TYPES[st.t].kind}${st.deep ? ', deep spot' : ''}">${ico(st.t)}<span class="cn">${esc(st.res)}${st.deep ? '<small>deep</small>' : ''}</span></span>`;
    let h = '<span></span>' + B.map((_, k) => `<span class="hd">Spot ${k + 1}</span>`).join('');
    h += `<span class="rl">Bacteria</span>${B.map((st, k) => chip('bact', st, k)).join('')}`;
    if (H) h += `<span class="rl">Human</span>${H.map((st, k) => chip('human', st, k)).join('')}`;
    h += '<span class="rl">Your molecule</span>' + this.drug.map((t, k) =>
      `<button type="button" class="slot" data-k="${k}" aria-pressed="${k === this.sel}" ${busy ? 'disabled' : ''} aria-label="Spot ${k + 1} of your molecule: ${TYPES[t].name.toLowerCase()}. Select to change it.">${ico(t)}</button>`).join('');
    if (M.bendable) h += '<span class="rl">Bends</span>' + this.drug.map((_, k) => {
      if (k === 0 || k === N - 1) return '<span></span>';
      const b = BEND_TXT[this.bends[k - 1]];
      return `<button type="button" class="bend" data-j="${k - 1}" ${busy ? 'disabled' : ''} aria-label="Joint at spot ${k + 1}: ${b.label}. Select to change it.">${b.svg}<small>${b.label}</small></button>`;
    }).join('');
    pm.innerHTML = h;
    $$('#pmap .slot').forEach(b => b.addEventListener('click', () => { this.sel = +b.dataset.k; Sound.tick(); this.renderBench(); $(`#pmap .slot[data-k="${this.sel}"]`).focus(); }));
    $$('#pmap .bend').forEach(b => b.addEventListener('click', () => { const j = +b.dataset.j; this.setBend(j); const nb = $(`#pmap .bend[data-j="${j}"]`); if (nb) nb.focus(); }));
    $('#shapeWrap').hidden = !M.bendable; if (M.bendable) this.drawShape();
    this.benchTail(busy);
  },
  drawShape() {   // the pocket's shape (dotted) and the molecule's shape as currently bent (solid)
    const cv = $('#shapeCv'), { ctx, w, h } = fitCanvas(cv), M = this.X, N = this.drug.length; if (!w) return;
    this.shapeW = w; ctx.clearRect(0, 0, w, h);
    const D = dockPose(M.bact.bends.split(''), N), mol = alignTo(buildShape(this.bends, N), D);
    let x0 = 1e9, x1 = -1e9, y0 = 1e9, y1 = -1e9; D.concat(mol).forEach(p => { x0 = Math.min(x0, p[0]); x1 = Math.max(x1, p[0]); y0 = Math.min(y0, p[1]); y1 = Math.max(y1, p[1]); });
    const sc = Math.min((w - 40) / (x1 - x0 + 1), (h - 24) / (y1 - y0 + 1)), cx = (x0 + x1) / 2, cy = (y0 + y1) / 2;
    const X = p => w / 2 + (p[0] - cx) * sc, Y = p => h / 2 - (p[1] - cy) * sc, r = sc * 0.36;
    ctx.save(); ctx.setLineDash([4, 4]); ctx.lineWidth = 2; ctx.strokeStyle = 'rgba(168,197,204,0.75)';
    ctx.beginPath(); D.forEach((p, k) => ctx[k ? 'lineTo' : 'moveTo'](X(p), Y(p))); ctx.stroke();
    D.forEach(p => { ctx.beginPath(); ctx.arc(X(p), Y(p), r, 0, TAU); ctx.stroke(); }); ctx.restore();
    const ok = this.bends.join('') === M.bact.bends;
    ctx.strokeStyle = ok ? '#9BE7B0' : '#EAF6F4'; ctx.lineWidth = 3; ctx.lineJoin = ctx.lineCap = 'round';
    ctx.beginPath(); mol.forEach((p, k) => ctx[k ? 'lineTo' : 'moveTo'](X(p), Y(p))); ctx.stroke();
    mol.forEach((p, k) => drawPart(ctx, X(p), Y(p), r * 0.8, this.drug[k] === 'R' ? 'N' : this.drug[k], false));
    $('#shapeMsg').textContent = ok ? 'Your molecule\'s shape matches the pocket.' : 'Dotted: the pocket. Solid: your molecule. Bend it to match.';
  },
  renderStageBox() {
    const box = $('#stageBox'), R = this.race, M = this.M; let h = '';
    if (this.note) h += `<div class="box"><p style="margin:0">${esc(this.note)}</p></div>`;
    if (this.phase === 'stagewin') {
      h += `<div class="box"><p class="box-title">It works!</p><p>Your molecule blocks the bacterial enzyme. But bacteria multiply fast, and every so often a mutation changes one of their amino acids. What happens if one changes inside the pocket?</p><button class="btn primary" id="evolveBtn" type="button">Let the bacteria evolve</button></div>`;
    } else if (this.mode === 'mission' && this.phase !== 'done' && this.mutation) {
      h += `<div class="box warn"><p class="box-title">Superbug!</p><p style="margin:0">${esc(M.mutation.event)}</p></div>`;
    } else if (this.phase === 'done') {
      const L = this.list(), nxt = L[L.indexOf(M) + 1];
      h += `<div class="box"><p class="box-title">Mission complete!</p><div class="stars" role="img" aria-label="${this.starsWon} of 3 stars">${starsSVG(this.starsWon)}</div>
        <p>You designed a working antibiotic in ${this.tests} test${this.tests === 1 ? '' : 's'}.${this.starsWon < 3 ? ' Try again for three stars by thinking it through before you test.' : ''}</p>
        <p class="small">${M.done}</p>
        <div class="btnrow">${nxt ? '<button class="btn primary" id="nextBtn" type="button">Next mission</button>' : M.expert ? '<button class="btn primary" data-go="missions" type="button">All missions</button>' : '<button class="btn primary" data-go="race" type="button">Try the arms race</button><button class="btn" id="expertBtn" type="button">Expert missions</button>'}<button class="btn" id="againBtn" type="button">Play again</button></div></div>`;
    } else if (R && this.phase === 'evolving' && this.evoStep === 'waiting') {
      h += `<div class="box"><p class="box-title">Blocked!</p><p style="margin:0">You beat generation ${R.gen}. The bacteria are evolving…</p></div>`;
    } else if (R && this.phase !== 'over' && this.mutation) {
      const mu = this.mutation;
      h += `<div class="box warn"><p class="box-title">Generation ${R.gen}</p><p style="margin:0">A mutation swapped ${TYPES[mu.from].resFull} (${TYPES[mu.from].kind}) for ${TYPES[mu.to].resFull} (${TYPES[mu.to].kind}) at the ${SPOTS[mu.spot].toLowerCase()} spot.</p></div>`;
    } else if (R && this.phase === 'over') {
      h += `<div class="box ${R.won ? '' : 'warn'}"><p class="box-title">${R.won ? 'You beat the superbug!' : 'The superbug wins'}</p>
        <p>${R.won ? `You held off all ${CONFIG.raceGenerations} generations` : `You held off ${R.survived} generation${R.survived === 1 ? '' : 's'}`} using ${R.tests} test${R.tests === 1 ? '' : 's'} in ${fmtTime(R.time)}.</p>
        ${R.survived > 0 && !R.famed ? `<form id="fameForm"><label for="fameName">Add your name to the hall of fame</label><div class="row"><input type="text" id="fameName" maxlength="14" autocomplete="off" placeholder="Nickname"><button class="btn primary" type="submit">Add</button></div><p class="small" style="margin:6px 0 0">Please use a nickname, not your full name.</p></form>` : ''}
        ${R.famed ? '<p>You\'re on the board. <button class="link-btn" data-go="fame" type="button">See the hall of fame</button></p>' : ''}
        <div class="btnrow"><button class="btn primary" id="raceAgain" type="button">Play again</button></div></div>`;
    }
    box.innerHTML = h;
    const on = (id, f) => { const el = $('#' + id); if (el) el.addEventListener('click', f); };
    on('evolveBtn', () => { this.note = ''; this.evolveMission(); });
    on('nextBtn', () => { const L = this.list(); this.openMission(L[L.indexOf(M) + 1]); $('#screen-lab').scrollTop = 0; });
    on('expertBtn', () => { this.openMission(XMISSIONS[0]); $('#screen-lab').scrollTop = 0; });
    on('againBtn', () => this.openMission(M));
    on('raceAgain', () => { this.startRace(); $('#screen-lab').scrollTop = 0; });
    const f = $('#fameForm');
    if (f) f.addEventListener('submit', e => {
      e.preventDefault(); const nm = $('#fameName').value.replace(/[\u0000-\u001f<>]/g, '').replace(/\s+/g, ' ').trim().slice(0, 14);
      if (!nm) { $('#fameName').focus(); return; }
      Fame.add({ name: nm, gens: R.survived, tests: R.tests, time: R.time, at: Date.now() }); R.famed = true; this.renderStageBox();
    });
  },
  renderNotebook() {
    const wrap = $('#notebookWrap'), list = $('#notebook');
    wrap.hidden = !this.history.length;
    list.innerHTML = this.history.map((r, i) => `<li><button type="button" data-i="${i}" aria-label="Load design ${r.drug.split('').map(t => TYPES[t].name).join(', ')}">
      <span class="dots" aria-hidden="true">${r.drug.split('').map(ico).join('')}${this.X && this.X.bendable ? `<span class="nb-bends">${r.bends.split('').map(b => BEND_TXT[b].short).join('')}</span>` : ''}</span>
      <span>Bacteria ${r.bact}%${r.human != null ? `, human ${r.human}%` : ''}</span><span class="${r.pass ? 'ok' : 'bad'}">${r.pass ? 'Pass' : 'Fail'}</span></button></li>`).join('');
    $$('#notebook button').forEach(b => b.addEventListener('click', () => {
      if (this.busy()) return; const r = this.history[+b.dataset.i];
      r.drug.split('').forEach((t, k) => { if (this.parts.includes(t)) this.drug[k] = t; });
      if (this.X) { if (this.X.bendable && r.bends) this.bends = r.bends.split(''); this.applyDrug(); }
      else ['bact', 'human'].forEach(side => this.reps[side].forEach(s => s.setDrug(this.drug)));
      this.redock(); Sound.place(); this.renderBench(); this.renderGoals();
    }));
  },

  /* ----- results: bars, replica barcodes, verdicts and hints ----- */
  buildResults(fromLast) {
    const sides = fromLast ? (this.last.res.human != null ? ['bact', 'human'] : ['bact']) : this.assay.sides;
    $('#results').innerHTML = sides.map(side => `<div class="res" data-side="${side}">
      <div class="res-h"><span>${side === 'bact' ? 'Bacterial enzyme' : 'Human enzyme'}</span><b class="pct">0%</b></div>
      <div class="bar"><i style="width:0;background:${side === 'bact' ? '#9BE7B0' : '#FF7A6B'}"></i><span class="tick" style="left:calc(${side === 'bact' ? SIM.passBact : SIM.passHuman}% - 1px)" title="Goal"></span></div>
      <canvas class="barcode" aria-label="${SIM.replicas} replica simulations: bright where the molecule was in the pocket"></canvas><p class="verdict"></p></div>`).join('') + '<ul class="hints"></ul>';
  },
  updateResults(final) {
    const src = this.assay || this.last; if (!src) return;
    const code = src.code, frames = src.frames, f = this.assay ? this.assay.f : frames;
    Object.keys(code).forEach(side => {
      const el = $(`#results .res[data-side="${side}"]`); if (!el) return;
      let ins = 0; code[side].forEach(row => { for (let i = 0; i < f; i++) ins += row[i]; });
      const pct = f ? Math.round(100 * ins / (f * SIM.replicas)) : 0;
      $('.pct', el).textContent = pct + '%'; $('.bar i', el).style.width = pct + '%';
      this.drawBarcode($('.barcode', el), code[side], f, frames, side);
      const v = $('.verdict', el);
      if (final && this.last) {
        const r = this.last.res, ok = side === 'bact' ? r.blocked : r.safe; v.className = 'verdict ' + (ok ? 'ok' : 'bad');
        v.textContent = side === 'bact' ? (ok ? 'Blocks the bacterial enzyme' : r.bact >= 50 ? 'Falls out too often' : 'Doesn\'t stay in the pocket')
          : (ok ? 'Leaves the human enzyme alone' : 'Sticks to the human enzyme: side effects');
      } else { v.textContent = ''; v.className = 'verdict'; }
    });
    const hl = $('#results .hints');
    if (hl) hl.innerHTML = final && this.last && !this.last.res.pass && this.last.res.counted ? this.hints(this.last.res).map(x => `<li>${x}</li>`).join('') : '';
  },
  drawBarcode(cv, rows, f, frames, side) {
    const { ctx, w, h } = fitCanvas(cv), R = rows.length, gap = 2, rh = (h - gap * (R - 1)) / R, on = side === 'bact' ? '#9BE7B0' : '#FF7A6B';
    ctx.clearRect(0, 0, w, h);
    rows.forEach((row, r) => {
      const y = r * (rh + gap); ctx.fillStyle = '#143A55'; ctx.fillRect(0, y, w, rh);
      let i = 0;
      while (i < f) { let j = i; while (j < f && row[j] === row[i]) j++; ctx.fillStyle = row[i] ? on : '#1D4B66'; ctx.fillRect(w * i / frames, y, Math.max(1, w * (j - i) / frames), rh); i = j; }
    });
  },
  hints(res) {
    if (this.X) return this.xhints(res);
    const out = [], d = res.drug.split(''), pk = res.pocket.split(''), strong = [];
    const say = (k, part, resT) => {
      const P = TYPES[part], Rt = TYPES[resT], spot = `<strong>${SPOTS[k]}:</strong> `;
      if (part === resT && (part === '+' || part === '-')) return spot + `your ${P.kind} part and ${Rt.res} are both ${P.kind}, so they push apart.`;
      if (part === 'O') return spot + `your oily part sits next to ${Rt.res}, which is ${Rt.kind}. Oily parts only like oily spots.`;
      if (resT === 'O') return spot + `your ${P.kind} part sits next to oily ${Rt.res}. ${P.name} parts don't like oily spots.`;
      return spot + `your ${P.kind} part only sticks weakly to ${Rt.res}.`;
    };
    if (!res.blocked) {
      const bad = [], weak = [];
      d.forEach((t, k) => { const e = pairEps(t, pk[k]); if (e >= 1.4) strong.push(k); else if (e < 0) bad.push(k); else weak.push(k); });
      bad.forEach(k => out.push(say(k, d[k], pk[k])));
      if (strong.length >= 2 && !bad.length) out.push('So close! Two strong matches and one weak one. The jiggling is random, so you could test again, or look for a stronger match.');
      else if (strong.length < 2) { weak.forEach(k => { if (out.length < 2) out.push(say(k, d[k], pk[k])); }); out.push('Strong matches are oily next to oily, and positive next to negative. You need at least two.'); }
    }
    if (!res.safe && res.humanPocket) {
      const shared = d.map((t, k) => pairEps(t, res.humanPocket[k]) >= 1.4 ? SPOTS[k].toLowerCase() : null).filter(Boolean);
      out.push(`Your molecule fits the human pocket too${shared.length ? ` (at the ${shared.join(' and ')} spot${shared.length > 1 ? 's' : ''})` : ''}. Build on the spots where the two pockets are different: they're outlined in the map.`);
    }
    res.rules.forEach(r => { if (!r.ok) out.push(RULES[r.key].hint); });
    return out.slice(0, 3);
  },
  xsay(part, st) {   // why a part and a spot don't get on (expert pockets)
    const P = TYPES[part], R = st.res, rt = st.t;
    if (part === 'R') return `your ring sits on ${R}, which is ${TYPES[rt].kind}. Rings are greasy: they like flat rings, positive spots and oily spots.`;
    if (rt === 'A') return part === 'O' ? `oily parts stick to the flat ring of ${R}, but a positive part would stick harder (cation–\u2060π).`
      : `${R} has a flat, greasy ring that pushes ${P.kind} parts away. A positive part would sit on it nicely (cation–\u2060π).`;
    if (part === rt && (part === '+' || part === '-')) return `your ${P.kind} part and ${R} are both ${P.kind}, so they push apart.`;
    if (part === 'O') return `your oily part sits next to ${R}, which is ${TYPES[rt].kind}. Oily parts only like oily spots and flat rings.`;
    if (rt === 'O') return `your ${P.kind} part sits next to oily ${R}. ${P.name} parts don't like oily spots.`;
    return `your ${P.kind} part only sticks weakly to ${R}.`;
  },
  xhints(res) {
    const out = [], d = res.drug.split(''), M = this.X, B = M.bact.sites, sp = k => `<strong>Spot ${k + 1}:</strong> `;
    const shapeOK = !M.bendable || res.bends === M.bact.bends;
    if (!res.blocked) {
      const bad = [], weak = [];
      if (!shapeOK) bad.push('Your molecule is the wrong shape for this pocket, so it bumps into the walls. Change the bends until your shape matches the dotted one.');
      d.forEach((t, k) => {
        const st = B[k];
        if (t === 'R' && !st.deep) bad.push(sp(k) + `there's no room for a ring here: ${st.res} is in the way. Rings only fit deep spots.`);
        else if (t !== 'R' && st.deep) bad.push(sp(k) + `this is a deep spot. Only a ring hangs down far enough to reach ${st.res}.`);
        else { const e = pairEpsX(t, st.t); if (e < 0) bad.push(sp(k) + this.xsay(t, st)); else if (e < 1.4) weak.push(sp(k) + this.xsay(t, st)); }
      });
      bad.forEach(x => out.push(x));
      if (!bad.length) { weak.forEach(x => { if (out.length < 2) out.push(x); }); out.push('In these longer pockets every spot counts. The strongest matches are a ring on a flat ring (π–\u2060π), a positive part on a flat ring or a ring on a positive spot (cation–\u2060π), positive with negative, and oily with oily.'); }
    }
    if (!res.safe && res.humanPocket) {
      const Hs = res.humanPocket.sites, diffs = Hs.map((h, k) => (h.t !== B[k].t || !!h.deep !== !!B[k].deep) ? 'spot ' + (k + 1) : null).filter(Boolean);
      out.push(`Your molecule fits the human pocket too. The two pockets differ at ${diffs.join(' and ')} (outlined in the map): choose parts there that suit the bacterial pocket but not the human one.`);
    }
    res.rules.forEach(r => { if (!r.ok) out.push(RULES[r.key].hint); });
    return out.slice(0, 3);
  },
  setNote(t) { const n = $('#stageNote'); n.hidden = !t; n.textContent = t; },

  /* ----- canvas ----- */
  bindCanvas() {
    const cv = $('#labCanvas');
    cv.addEventListener('pointerdown', e => {
      if (this.assay) return;
      const r = cv.getBoundingClientRect(), mx = e.clientX - r.left, my = e.clientY - r.top;
      this.panels.forEach(P => {
        if (mx < P.px0 || mx > P.px0 + P.pw || my < P.py0 || my > P.py0 + P.ph) return;
        const wx = (mx - P.X0) / P.s, wy = -(my - P.Y0) / P.s, sim = this.shown(P.side); let bi = -1, bd = 0.9 * 0.9;
        const i0 = sim.gen ? sim.np : 26, i1 = sim.gen ? sim.np + sim.nd : 29;
        for (let i = i0; i < i1; i++) { const d = (sim.x[i] - wx) ** 2 + (sim.y[i] - wy) ** 2; if (d < bd) { bd = d; bi = i; } }
        if (bi >= 0) { sim.grab = { i: bi, x: wx, y: wy }; this.grab = P; cv.setPointerCapture(e.pointerId); e.preventDefault(); }
      });
    });
    cv.addEventListener('pointermove', e => {
      if (!this.grab) return; const P = this.grab, r = cv.getBoundingClientRect(), sim = this.shown(P.side);
      sim.grab.x = (e.clientX - r.left - P.X0) / P.s; sim.grab.y = -(e.clientY - r.top - P.Y0) / P.s;
    });
    const end = () => this.onUp(); cv.addEventListener('pointerup', end); cv.addEventListener('pointercancel', end);
  },
  onUp() { if (!this.grab) return; this.shown(this.grab.side).grab = null; this.grab = null; },
  tick() {
    if (this.X && this.X.bendable) { const cw = $('#shapeCv').clientWidth; if (cw && cw !== this.shapeW) this.drawShape(); }   // first time the panel is visible
    if (this.assay) this.stepAssay();
    else { this.shown('bact').step(40); if (this.human) this.shown('human').step(40); }
    const cv = $('#labCanvas'), { ctx, w, h } = fitCanvas(cv); ctx.clearRect(0, 0, w, h);
    const sides = this.human ? ['bact', 'human'] : ['bact'], side2 = w >= 640 && w / h > 1.05;
    let box = CLASSIC_BOX;   // both panels share one scale so the pockets can be compared
    if (this.X) { const bs = sides.map(sd => this.shown(sd).box), top = Math.max(...bs.map(b => b.top)), bot = Math.min(...bs.map(b => b.top - b.h)); box = { w: Math.max(...bs.map(b => b.w)), top, h: top - bot }; }
    this.panels = sides.map((side, k) => {
      const n = sides.length, pw = side2 ? w / n : w, ph = side2 ? h : h / n;
      const P = panelGeom(side2 ? k * pw : 0, side2 ? 0 : k * ph, pw, ph, 52, 36, box); P.side = side; return P;
    });
    this.panels.forEach(P => drawEnzyme(ctx, this.shown(P.side), P, {
      title: P.side === 'bact' ? 'Bacterial enzyme' : 'Human enzyme', status: true, goodWhenBound: P.side === 'bact',
      flashSpot: P.side === 'bact' ? this.flash.spot : -1, flashT: this.flash.t
    }));
    if (sides.length === 2) {
      ctx.strokeStyle = 'rgba(234,246,244,0.1)'; ctx.lineWidth = 1; ctx.beginPath();
      if (side2) { ctx.moveTo(w / 2, 28); ctx.lineTo(w / 2, h - 16); } else { ctx.moveTo(16, h / 2); ctx.lineTo(w - 16, h / 2); } ctx.stroke();
    }
  }
};
// bacterial pockets the race can use: the enzyme must still work (at most one water-loving spot), and a good answer must exist
function raceOK(b, H) {
  if (b.split('').filter(t => t === 'P').length > 1) return false;
  for (let i = 0; i < 64; i++) { const m = TYPE_ORDER[i >> 4] + TYPE_ORDER[(i >> 2) & 3] + TYPE_ORDER[i & 3]; if (predicted(m, b) >= RACE_SOLVE.bact && predicted(m, H) <= RACE_SOLVE.human) return true; }
  return false;
}
function raceStates(H) { const out = []; for (let i = 0; i < 64; i++) { const b = TYPE_ORDER[i >> 4] + TYPE_ORDER[(i >> 2) & 3] + TYPE_ORDER[i & 3]; if (raceOK(b, H)) out.push(b); } return out; }

/* =====================================================================
   Science page widgets
   ===================================================================== */
function supPow(mant, exp) { return (mant ? mant + ' × ' : '') + '10<sup>' + exp + '</sup>'; }
function updateMdCalc(t) {
  const steps = t * 1e15 / CONFIG.timestepFs; $('#mdSteps').innerHTML = bigWords(steps) + ' steps';
  const days = (t * 1e9) / CONFIG.gpuNsPerDay;
  const dur = days < 1 / 24 ? `about ${Math.max(1, Math.round(days * 1440))} minutes` : days < 2 ? `about ${Math.round(days * 24)} hours` : days < 365 ? `about ${Math.round(days)} days` : `about ${bigWords(days / 365.25)} years`;
  $('#mdCost').textContent = `With ${CONFIG.timestepFs}-femtosecond steps. For a small protein in water, one modern graphics card (GPU) might simulate roughly ${CONFIG.gpuNsPerDay} nanoseconds per day, so this would take ${dur}.`;
}
function siteHost() { try { return new URL(CONFIG.groupWebsite).host + new URL(CONFIG.groupWebsite).pathname.replace(/\/$/, ''); } catch (e) { return CONFIG.groupWebsite; } }
function initLearn() {
  $$('#mdTimeSeg button').forEach(b => b.addEventListener('click', () => { $$('#mdTimeSeg button').forEach(x => x.setAttribute('aria-pressed', String(x === b))); updateMdCalc(+b.dataset.t); }));
  updateMdCalc(1e-6);
  $('#chemTable').innerHTML = TYPE_ORDER.map(t => `<tr><td>${ico(t)} ${TYPES[t].name}</td><td>${TYPES[t].group}</td><td>${STICKS[t]}</td></tr>`).join('');
  $('#aboutBody').innerHTML = CONFIG.aboutParagraphs.map(p => `<p>${esc(p)}</p>`).join('') +
    (CONFIG.groupWebsite ? `<p><a href="${esc(CONFIG.groupWebsite)}" target="_blank" rel="noopener">Visit our website: ${esc(siteHost())}</a></p>` : '');
}

/* =====================================================================
   Hall of fame (arms race)
   ===================================================================== */
const Fame = {
  list: store.get('fame', []),
  save() { store.set('fame', this.list); },
  sorted() { return this.list.slice().sort((a, b) => b.gens - a.gens || a.tests - b.tests || a.time - b.time); },
  best() { return this.sorted()[0] || null; },
  add(e) { this.list.push(e); this.save(); },
  remove(i) { this.list.splice(i, 1); this.save(); },
  render() {
    const body = $('#fameBody');
    if (!this.list.length) { body.innerHTML = `<div class="empty"><h3>No one's on the board yet</h3><p>Play the superbug arms race to add your name.</p><button class="btn primary" data-go="race">Play the arms race</button></div>`; return; }
    body.innerHTML = '<ol class="fame-list"><li class="fame-head"><span></span><span>Name</span><span>Generations</span><span>Tests</span><span class="tm">Time</span></li>' +
      this.sorted().slice(0, 10).map((e, k) => `<li><span class="rank">${k + 1}</span><span class="nm">${esc(e.name)}</span><span>${e.gens}</span><span class="mv">${e.tests}</span><span class="mv tm">${fmtTime(e.time)}</span></li>`).join('') + '</ol>';
  },
  renderAdmin() {
    const ul = $('#fameAdmin');
    ul.innerHTML = this.list.length ? this.list.map((e, i) => `<li><span>${esc(e.name)}, ${e.gens} generations, ${e.tests} tests</span><button class="btn sm quiet" data-rm="${i}">Remove</button></li>`).join('') : '<li class="small">No entries yet.</li>';
  }
};
enterHooks.fame = () => Fame.render();

/* =====================================================================
   Settings, sound toggle, idle reset
   ===================================================================== */
function syncSoundBtn() {
  const b = $('#soundBtn'); b.setAttribute('aria-pressed', String(Sound.on));
  b.querySelector('.on').style.display = Sound.on ? '' : 'none'; b.querySelector('.off').style.display = Sound.on ? 'none' : '';
  $('#soundLabel').textContent = Sound.on ? 'Sound on' : 'Sound off';
}
$('#soundBtn').addEventListener('click', () => { Sound.on = !Sound.on; store.set('sound', Sound.on); syncSoundBtn(); if (Sound.on) Sound.tick(); });
$('#settingsBtn').addEventListener('click', () => { $('#setSound').checked = Sound.on; $('#setIdle').value = String(Settings.idle); Fame.renderAdmin(); $('#settingsDlg').showModal(); });
$('#closeSet').addEventListener('click', () => $('#settingsDlg').close());
$('#setSound').addEventListener('change', e => { Sound.on = e.target.checked; store.set('sound', Sound.on); syncSoundBtn(); });
$('#setIdle').addEventListener('change', e => { Settings.idle = +e.target.value; store.set('idle', Settings.idle); });
$('#newPlayerBtn').addEventListener('click', () => { newPlayer(); $('#settingsDlg').close(); go('home'); });
$('#fullBtn').addEventListener('click', () => { if (document.fullscreenElement) document.exitFullscreen(); else if (document.documentElement.requestFullscreen) document.documentElement.requestFullscreen().catch(() => {}); });
$('#clearFameBtn').addEventListener('click', () => { if (confirm('Remove every name from the hall of fame?')) { Fame.list = []; Fame.save(); Fame.renderAdmin(); if (current === 'fame') Fame.render(); } });
$('#fameAdmin').addEventListener('click', e => { const b = e.target.closest('[data-rm]'); if (!b) return; Fame.remove(+b.dataset.rm); Fame.renderAdmin(); if (current === 'fame') Fame.render(); });
function newPlayer() { progress.clear(); Lab.cancel(); Lab.mode = null; Lab.race = null; }
const Idle = {
  last: Date.now(), timer: null, left: 0,
  poke() { this.last = Date.now(); if (this.timer) { clearInterval(this.timer); this.timer = null; $('#idleOverlay').hidden = true; } },
  check() {
    if (!Settings.idle || current === 'home' || this.timer || Lab.assay) return;
    if (Date.now() - this.last > Settings.idle * 60000) {
      this.left = 15; $('#idleCount').textContent = this.left; $('#idleOverlay').hidden = false;
      this.timer = setInterval(() => {
        this.left--; $('#idleCount').textContent = this.left;
        if (this.left <= 0) { clearInterval(this.timer); this.timer = null; $('#idleOverlay').hidden = true; if ($('#settingsDlg').open) $('#settingsDlg').close(); newPlayer(); go('home'); this.last = Date.now(); }
      }, 1000);
    }
  }
};
['pointerdown', 'keydown', 'wheel', 'touchstart'].forEach(ev => window.addEventListener(ev, () => Idle.poke(), { passive: true, capture: true }));
setInterval(() => Idle.check(), 1000);

/* =====================================================================
   Boot
   ===================================================================== */
FONT = getComputedStyle(document.body).fontFamily;
$('#heroT1').textContent = CONFIG.titleLine1; $('#heroT2').textContent = CONFIG.titleLine2;
$('#brandTitle').textContent = CONFIG.titleLine1 + ' ' + CONFIG.titleLine2; document.title = CONFIG.titleLine1 + ' ' + CONFIG.titleLine2;
$('#heroGroup').innerHTML = `Made by the <strong>${esc(CONFIG.groupName)}</strong>${CONFIG.groupPlace ? ', ' + esc(CONFIG.groupPlace) : ''}. ${esc(CONFIG.groupTagline)}.` +
  (CONFIG.groupWebsite ? ` <a href="${esc(CONFIG.groupWebsite)}" target="_blank" rel="noopener">${esc(siteHost())}</a>` : '');
syncSoundBtn(); Hero.init(); Lab.init(); initLearn();
{ const h = (location.hash || '#home').slice(1); go(h === 'lab' ? 'missions' : h, false); }
let lastT = performance.now();
function frame(t) {
  const dt = Math.min(0.05, Math.max(0, (t - lastT) / 1000)); lastT = t;
  try { if (current === 'home') Hero.tick(dt); else if (current === 'lab') Lab.tick(dt); } catch (err) { console.error(err); }
  requestAnimationFrame(frame);
}
requestAnimationFrame(frame);
