/* =====================================================================
   Molecular dynamics model: a small drug molecule in an enzyme pocket.
   2D Langevin dynamics (BAOAB) in reduced units. Shared by the game and
   by the offline script that pre-computes the results table.
   ===================================================================== */
let gaussSpare = null;
function gauss() {
  if (gaussSpare !== null) { const g = gaussSpare; gaussSpare = null; return g; }
  let u, v, s; do { u = Math.random() * 2 - 1; v = Math.random() * 2 - 1; s = u * u + v * v; } while (s >= 1 || s === 0);
  const m = Math.sqrt(-2 * Math.log(s) / s); gaussSpare = v * m; return u * m;
}
// part/residue types: O oily, P water-loving, + positive, - negative, N inert protein surface
const TYPE_ORDER = ['O', 'P', '+', '-'];
// how strongly a molecule part and a pocket residue stick (units of epsilon; negative = push apart)
function pairEps(a, b) {
  if (a === 'N' || b === 'N') return 0;
  if (a === 'O' && b === 'O') return 1.4;                                  // oily with oily
  if ((a === '+' && b === '-') || (a === '-' && b === '+')) return 1.4;    // salt bridge
  if (a === b && (a === '+' || a === '-')) return -0.9;                    // like charges repel
  if (a === 'O' || b === 'O') return -0.3;                                 // a charge or polar group buried in grease
  return 0.45;                                                             // hydrogen bonds: polar with polar or charged
}
const LINING = [22, 19, 16];                      // protein beads lining the pocket: left, middle, right
const DOCK = [[-0.935, -0.54], [0, -1.08], [0.935, -0.54]], DOCK_COM = [0, -0.72];
const SIM = { kT: 0.3, dt: 0.008, T: 500, replicas: 8, passBact: 85, passHuman: 50, rmsdCut: 0.75 };

class PocketSim {
  constructor() {
    const P = [], T = [];
    for (let k = 0; k < 13; k++) { const a = (150 + 20 * k) * Math.PI / 180; P.push([3.2 * Math.cos(a), 3.2 * Math.sin(a)]); T.push('N'); }
    for (let k = 0; k < 13; k++) { const a = (390 - 20 * k) * Math.PI / 180; P.push([2.2 * Math.cos(a), 2.2 * Math.sin(a)]); T.push('N'); }
    this.np = 26; this.n = 29; this.native = P.concat(DOCK); this.type = T.concat(['P', 'P', 'P']);
    ['x', 'y', 'vx', 'vy', 'fx', 'fy'].forEach(k => this[k] = new Float64Array(this.n));
    const dist = (a, b) => Math.hypot(a[0] - b[0], a[1] - b[1]), bonds = [];
    for (let i = 0; i < 25; i++) bonds.push([i, i + 1, dist(P[i], P[i + 1]), 150]);
    for (let i = 0; i < 26; i++) for (let j = i + 2; j < 26; j++) { const d = dist(P[i], P[j]); if (d < 2.3) bonds.push([i, j, d, 12]); }  // elastic network keeps the fold
    bonds.push([26, 27, 1.08, 150], [27, 28, 1.08, 150]);
    this.nb = bonds.length; this.bI = Int32Array.from(bonds, b => b[0]); this.bJ = Int32Array.from(bonds, b => b[1]);
    this.bR = Float64Array.from(bonds, b => b[2]); this.bK = Float64Array.from(bonds, b => b[3]);
    this.eps = new Float64Array(3 * 26);
    this.p = { kT: SIM.kT, dt: SIM.dt, gamma: 1, kr: 1.5, ka: 40, wallR: 3.4, wallY: 1.0 };
    this.grab = null; this.guide = 0; this.reset();
  }
  setPocket(pk) { for (let k = 0; k < 3; k++) this.type[LINING[k]] = pk[k]; this.tab(); }
  setDrug(d) { for (let k = 0; k < 3; k++) this.type[26 + k] = d[k]; this.tab(); }
  tab() { for (let a = 0; a < 3; a++) for (let b = 0; b < 26; b++) this.eps[a * 26 + b] = pairEps(this.type[26 + a], this.type[b]); }
  thermalise() { const s = Math.sqrt(this.p.kT); for (let i = 0; i < this.n; i++) { this.vx[i] = gauss() * s; this.vy[i] = gauss() * s; } }
  reset() { for (let i = 0; i < this.n; i++) { this.x[i] = this.native[i][0]; this.y[i] = this.native[i][1]; } this.thermalise(); this.forces(); }
  dock() { for (let k = 0; k < 3; k++) { this.x[26 + k] = DOCK[k][0]; this.y[26 + k] = DOCK[k][1]; this.vx[26 + k] = this.vy[26 + k] = 0; } this.forces(); }
  forces() {
    const { x, y, fx, fy, p } = this; fx.fill(0); fy.fill(0);
    const bI = this.bI, bJ = this.bJ, bR = this.bR, bK = this.bK, E = this.eps;
    for (let q = 0; q < this.nb; q++) {
      const i = bI[q], j = bJ[q], dx = x[j] - x[i], dy = y[j] - y[i], r = Math.sqrt(dx * dx + dy * dy) || 1e-9, f = -bK[q] * (r - bR[q]) / r;
      fx[j] += f * dx; fy[j] += f * dy; fx[i] -= f * dx; fy[i] -= f * dy;
    }
    for (let i = 0; i < 26; i++) { fx[i] -= p.kr * (x[i] - this.native[i][0]); fy[i] -= p.kr * (y[i] - this.native[i][1]); }
    { // keep the molecule bent at about 120 degrees: U = ka (cos t - cos t0)^2
      const ax = x[26] - x[27], ay = y[26] - y[27], bx = x[28] - x[27], by = y[28] - y[27];
      const la = Math.hypot(ax, ay) || 1e-9, lb = Math.hypot(bx, by) || 1e-9, c = (ax * bx + ay * by) / (la * lb), g = 2 * p.ka * (c + 0.5), iab = 1 / (la * lb);
      const fax = -g * (bx * iab - c * ax / (la * la)), fay = -g * (by * iab - c * ay / (la * la));
      const fbx = -g * (ax * iab - c * bx / (lb * lb)), fby = -g * (ay * iab - c * by / (lb * lb));
      fx[26] += fax; fy[26] += fay; fx[28] += fbx; fy[28] += fby; fx[27] -= fax + fbx; fy[27] -= fay + fby;
    }
    const rc2 = 6.25, rmin2 = 1.2599210498948732;
    for (let a = 26; a < 29; a++) for (let b = 0; b < 26; b++) {
      const dx = x[b] - x[a], dy = y[b] - y[a], r2 = dx * dx + dy * dy; if (r2 > rc2) continue;
      const eps = E[(a - 26) * 26 + b]; if (!eps && r2 > rmin2) continue;
      const inv2 = 1 / Math.max(r2, 0.36), s6 = inv2 * inv2 * inv2;
      const f = (r2 < rmin2 ? 24 : eps * 24) * (2 * s6 * s6 - s6) * inv2;
      fx[b] += f * dx; fy[b] += f * dy; fx[a] -= f * dx; fy[a] -= f * dy;
    }
    for (let a = 26; a < 29; a++) {
      const dx = x[a], dy = y[a] - p.wallY, r = Math.hypot(dx, dy);
      if (r > p.wallR) { const f = -4 * (r - p.wallR) / r; fx[a] += f * dx; fy[a] += f * dy; }
    }
    if (this.guide > 0) for (let k = 0; k < 3; k++) { fx[26 + k] += this.guide * (DOCK[k][0] - x[26 + k]); fy[26 + k] += this.guide * (DOCK[k][1] - y[26 + k]); }
    if (this.grab) {
      const g = this.grab; let gx = 20 * (g.x - x[g.i]), gy = 20 * (g.y - y[g.i]); const m = Math.hypot(gx, gy);
      if (m > 50) { gx *= 50 / m; gy *= 50 / m; } fx[g.i] += gx; fy[g.i] += gy;
    }
  }
  step(ns) {
    const { x, y, vx, vy, fx, fy, n, p } = this, dt = p.dt, h = 0.5 * dt, c1 = Math.exp(-p.gamma * dt), c2 = Math.sqrt((1 - c1 * c1) * p.kT);
    for (let s = 0; s < ns; s++) {
      for (let i = 0; i < n; i++) { vx[i] += h * fx[i]; vy[i] += h * fy[i]; x[i] += h * vx[i]; y[i] += h * vy[i]; }
      for (let i = 0; i < n; i++) { vx[i] = c1 * vx[i] + c2 * gauss(); vy[i] = c1 * vy[i] + c2 * gauss(); x[i] += h * vx[i]; y[i] += h * vy[i]; }
      this.forces();
      for (let i = 0; i < n; i++) {
        vx[i] += h * fx[i]; vy[i] += h * fy[i];
        const v2 = vx[i] * vx[i] + vy[i] * vy[i]; if (v2 > 400) { const k = 20 / Math.sqrt(v2); vx[i] *= k; vy[i] *= k; }
      }
    }
    if (!Number.isFinite(x[n - 1])) { this.reset(); this.dock(); }
  }
  rmsd() {   // how far the molecule is from its docked pose (no fitting: the protein stays in place)
    let s = 0; for (let k = 0; k < 3; k++) s += (this.x[26 + k] - DOCK[k][0]) ** 2 + (this.y[26 + k] - DOCK[k][1]) ** 2;
    return Math.sqrt(s / 3);
  }
  bound() { return this.rmsd() < SIM.rmsdCut; }
}
if (typeof module !== 'undefined') module.exports = { PocketSim, pairEps, TYPE_ORDER, SIM, LINING, DOCK };
