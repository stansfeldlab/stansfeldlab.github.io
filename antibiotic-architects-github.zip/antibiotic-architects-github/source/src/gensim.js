/* =====================================================================
   Expert engine: longer molecules (4-5 parts) that can bend, ring parts
   that stick out from the molecule and need a deep spot to slot into,
   aromatic pocket residues (pi-pi stacking, pi-cation), and pockets
   generated in different shapes. Same 2D Langevin dynamics as the
   classic pocket (uses gauss, pairEps, SIM and PocketSim.step).
   ===================================================================== */
const RING_SIGMA = 1.4;                   // the hexagon that hangs below a ring part
const RES_SIGMA = { A: 1.25 };            // aromatic side chains (Phe, Trp, Tyr) are bulky
const LP = 1.1;                           // ring sits this far below its part
const LJ_MIN = 1.122462;
const XSCALE = 0.7;                       // all attractions in expert pockets are multiplied by this
const XRANGE = 0.45;                      // width of the attractive well, in bead diameters (each part feels its own spot)
const XRIM = 140;                         // where the pocket's rim starts (degrees): an open, flared mouth
const XBAD = 2.0;                         // extra push from bad pairs (water-loving next to oily, like charges)
const XMAXDEV = 99;                       // a part further than this from its spot counts as unbound
const XWALL = 1.0;                        // room above the pocket for the molecule to drift away
const TURN = { S: 0, L: Math.PI / 3, R: -Math.PI / 3 };
function pairEpsX(a, b) {
  if (a === 'N' || b === 'N') return 0;
  const ring = a === 'R', aro = b === 'A';
  if (ring && aro) return 2.0;                                   // pi-pi stacking
  if ((ring && b === '+') || (a === '+' && aro)) return 1.8;     // pi-cation
  if (ring && b === 'O') return 1.2;                             // ring with an oily spot
  if (a === 'O' && aro) return 1.0;                              // oily part with an aromatic spot
  if (ring || aro) return -0.3;                                  // rings dislike water-loving and negative partners
  return pairEps(a, b);
}
const vnorm = v => { const m = Math.hypot(v[0], v[1]) || 1; return [v[0] / m, v[1] / m]; };
function rightNormals(P) {                // the side of the molecule that faces the protein
  const n = P.length;
  return P.map((p, k) => { const t = vnorm(k === 0 ? [P[1][0] - P[0][0], P[1][1] - P[0][1]] : k === n - 1 ? [P[k][0] - P[k - 1][0], P[k][1] - P[k - 1][1]] : [P[k + 1][0] - P[k - 1][0], P[k + 1][1] - P[k - 1][1]]); return [t[1], -t[0]]; });
}
function buildShape(bends, n) {           // backbone heading +x, turning 60 degrees at each bend
  const pts = [[0, 0]]; let ang = 0;
  for (let i = 1; i < n; i++) { if (i >= 2) ang += TURN[bends[i - 2]]; pts.push([pts[i - 1][0] + 1.08 * Math.cos(ang), pts[i - 1][1] + 1.08 * Math.sin(ang)]); }
  return pts;
}
function withRings(P, parts) {           // backbone + a ring bead below each ring part
  const r = rightNormals(P), out = P.map(p => p.slice());
  parts.forEach((t, k) => { if (t === 'R') out.push([P[k][0] + r[k][0] * LP, P[k][1] + r[k][1] * LP]); });
  return out;
}
function alignTo(src, dst) {              // best rotation + shift of src onto dst (no mirror images: a 2D molecule can't flip over)
  const n = src.length; let sx = 0, sy = 0, dx = 0, dy = 0;
  for (let i = 0; i < n; i++) { sx += src[i][0]; sy += src[i][1]; dx += dst[i][0]; dy += dst[i][1]; }
  sx /= n; sy /= n; dx /= n; dy /= n; let c = 0, d = 0;
  for (let i = 0; i < n; i++) { const ax = src[i][0] - sx, ay = src[i][1] - sy, bx = dst[i][0] - dx, by = dst[i][1] - dy; d += ax * bx + ay * by; c += ax * by - ay * bx; }
  const th = Math.atan2(c, d), co = Math.cos(th), si = Math.sin(th);
  return src.map(p => [dx + (p[0] - sx) * co - (p[1] - sy) * si, dy + (p[0] - sx) * si + (p[1] - sy) * co]);
}
function dockPose(bends, n) {             // the pocket's ideal backbone, rotated so the opening faces up
  const P = buildShape(bends, n), r = rightNormals(P); let mx = 0, my = 0;
  r.forEach(v => { mx -= v[0]; my -= v[1]; });
  const th = Math.PI / 2 - Math.atan2(my, mx), co = Math.cos(th), si = Math.sin(th);
  const R = P.map(p => [p[0] * co - p[1] * si, p[0] * si + p[1] * co]);
  let cx = 0, cy = 0; R.forEach(p => { cx += p[0]; cy += p[1]; }); cx /= n; cy /= n;
  return R.map(p => [p[0] - cx, p[1] - cy - 0.5]);
}
function genProtein(D, sites) {
  const N = D.length, deg = Math.PI / 180, right = rightNormals(D), dist = (a, b) => Math.hypot(a[0] - b[0], a[1] - b[1]);
  const tan = right.map(r => [-r[1], r[0]]);
  const pend = sites.map((s, k) => s.deep ? [D[k][0] + right[k][0] * LP, D[k][1] + right[k][1] * LP] : null);
  const sr = sites.map(s => RES_SIGMA[s.t] || 1);
  const holes = []; D.forEach(p => holes.push({ p, c: LJ_MIN * 0.98 })); pend.forEach(p => p && holes.push({ p, c: LJ_MIN * (1 + RING_SIGMA) / 2 * 0.98 }));
  const lining = [];
  sites.forEach((s, k) => {
    const a = pend[k] || D[k], d = LJ_MIN * (sr[k] + (pend[k] ? RING_SIGMA : 1)) / 2;
    let best = null;   // lean the residue away from a neighbour's ring hole, and from residues already placed
    for (let t = 0; t <= 60 && !best; t += 3) for (const sgn of [1, -1]) {
      const th = sgn * t * deg, v = [right[k][0] * Math.cos(th) - right[k][1] * Math.sin(th), right[k][0] * Math.sin(th) + right[k][1] * Math.cos(th)], q = [a[0] + v[0] * d, a[1] + v[1] * d];
      if (!best && pend.every((pp, j) => !pp || j === k || dist(q, pp) >= LJ_MIN * (sr[k] + RING_SIGMA) / 2 + 0.03) && lining.every(o => dist(q, o) >= 0.98)) best = q;
    }
    lining.push(best || [a[0] + right[k][0] * d, a[1] + right[k][1] * d]);
  });
  // dense points 1.15 from the molecule (and round each ring hole), in order from the left rim to the right rim
  const ds = 1.15, dense = [], push = p => dense.push(p);
  const arc = (c, rad, from, to) => { for (let t = from; t <= to + 1e-9; t += 3 * deg) push([c[0] + rad * Math.cos(t), c[1] + rad * Math.sin(t)]); };
  const holeArc = k => { if (!pend[k]) return; const a = Math.atan2(right[k][1], right[k][0]); arc(pend[k], LJ_MIN * (1 + RING_SIGMA) / 2 + 0.04, a - 110 * deg, a + 110 * deg); };
  const a0 = Math.atan2(tan[0][1], tan[0][0]), a1 = Math.atan2(tan[N - 1][1], tan[N - 1][0]);
  let sFrom = XRIM * deg, sTo = a0 - Math.PI / 2; while (sTo < sFrom) sTo += 2 * Math.PI;
  const rimS = [D[0][0] + ds * Math.cos(sFrom), D[0][1] + ds * Math.sin(sFrom)];
  for (let f = 1.0; f > 0; f -= 0.05) push([rimS[0] + f * Math.cos(sFrom), rimS[1] + f * Math.sin(sFrom)]);   // rims flare outwards
  arc(D[0], ds, sFrom, sTo); holeArc(0);
  for (let k = 0; k < N - 1; k++) {
    const u = vnorm([D[k + 1][0] - D[k][0], D[k + 1][1] - D[k][1]]), rs = [u[1], -u[0]];
    if (k > 0) {
      const up = vnorm([D[k][0] - D[k - 1][0], D[k][1] - D[k - 1][1]]), rp = [up[1], -up[0]];
      const a = Math.atan2(rp[1], rp[0]), da = Math.atan2(rs[1] * rp[0] - rs[0] * rp[1], rs[0] * rp[0] + rs[1] * rp[1]);
      for (let i = 1; i < 12; i++) { const t = a + da * i / 12; push([D[k][0] + ds * Math.cos(t), D[k][1] + ds * Math.sin(t)]); }
      holeArc(k);
    }
    for (let f = 0; f <= 1.0001; f += 0.04) push([D[k][0] + f * (D[k + 1][0] - D[k][0]) + ds * rs[0], D[k][1] + f * (D[k + 1][1] - D[k][1]) + ds * rs[1]]);
  }
  holeArc(N - 1);
  let eFrom = a1 - Math.PI / 2, eTo = (180 - XRIM) * deg; while (eTo < eFrom) eTo += 2 * Math.PI;
  arc(D[N - 1], ds, eFrom, eTo);
  const rimE = [D[N - 1][0] + ds * Math.cos(eTo), D[N - 1][1] + ds * Math.sin(eTo)];
  for (let f = 0.05; f <= 1.0; f += 0.05) push([rimE[0] + f * Math.cos(eTo), rimE[1] + f * Math.sin(eTo)]);
  // surface beads: lining residues first, then evenly spaced points that leave room for the molecule
  const pos = [], par = [];
  const nearestDense = p => { let bi = 0, bd = 1e9; dense.forEach((q, i) => { const d = dist(p, q); if (d < bd) { bd = d; bi = i; } }); return bi; };
  lining.forEach(p => { pos.push(p); par.push(nearestDense(p)); });
  dense.forEach((p, i) => {
    if (holes.some(h => dist(p, h.p) < h.c) || pos.some(q => dist(p, q) < 0.85)) return;
    pos.push(p); par.push(i);
  });
  const nSurf = pos.length;
  for (let i = 0; i < nSurf; i++) {        // a second layer behind the surface gives the protein a body
    const p = pos[i]; let bh = holes[0], bd = 1e9; holes.forEach(h => { const d = dist(p, h.p); if (d < bd) { bd = d; bh = h; } });
    const u = vnorm([p[0] - bh.p[0], p[1] - bh.p[1]]), b = [p[0] + 0.95 * u[0], p[1] + 0.95 * u[1]];
    if (holes.some(h => dist(b, h.p) < h.c + 0.8) || pos.some(q => dist(b, q) < 0.8)) continue;
    pos.push(b); par.push(par[i]);
  }
  const surf = [...Array(nSurf).keys()].sort((a, b) => par[a] - par[b]);
  const body = [...Array(pos.length - nSurf).keys()].map(i => i + nSurf).sort((a, b) => par[a] - par[b]);
  const type = pos.map(() => 'N'), sigma = pos.map(() => 1);
  sites.forEach((s, k) => { type[k] = s.t; sigma[k] = sr[k]; });
  return { pos, type, sigma, surf, body, normals: right, pend };
}

class GenPocketSim {
  constructor(def) {
    const N = def.sites.length, D = dockPose(def.bends, N), prot = genProtein(D, def.sites);
    this.gen = true; this.def = def; this.slots = N; this.np = prot.pos.length; this.dockPos = D; this.pendPos = prot.pend;
    this.native = prot.pos; this.surf = prot.surf; this.body = prot.body;
    this.lining = def.sites.map((s, k) => k); this.labelDir = prot.normals; this.siteW = def.sites.map(s => s.w == null ? 1 : s.w);
    const M = this.np + 2 * N; this.max = M;
    ['x', 'y', 'vx', 'vy', 'fx', 'fy', 'sigma'].forEach(k => this[k] = new Float64Array(M));
    this.type = Array(M).fill('N'); for (let i = 0; i < this.np; i++) { this.type[i] = prot.type[i]; this.sigma[i] = prot.sigma[i]; }
    const P = prot.pos, bonds = [];
    for (let i = 0; i < this.np; i++) for (let j = i + 1; j < this.np; j++) { const d = Math.hypot(P[i][0] - P[j][0], P[i][1] - P[j][1]); if (d < 2.3) bonds.push([i, j, d, d < 1.3 ? 40 : 12]); }
    this.protBonds = bonds;
    this.eps = new Float64Array(2 * N * this.np); this.sg2 = new Float64Array(2 * N * this.np);
    let cx = 0, top = -1e9; D.forEach(p => { cx += p[0] / N; top = Math.max(top, p[1]); });
    const wy = top + 1.7; let far = 0; D.forEach(p => { far = Math.max(far, Math.hypot(p[0] - cx, p[1] - wy)); });
    this.p = { kT: SIM.kT, dt: SIM.dt, gamma: 1, kr: 1.5, ka: 60, wallX: cx, wallY: wy, wallR: far + (def.wallPad || XWALL) };
    let x0 = 1e9, x1 = -1e9, y0 = 1e9, y1 = -1e9; prot.pos.forEach(q => { x0 = Math.min(x0, q[0]); x1 = Math.max(x1, q[0]); y0 = Math.min(y0, q[1]); y1 = Math.max(y1, q[1]); });
    const xh = Math.max(5.2, Math.abs(x0) + 0.9, Math.abs(x1) + 0.9), bTop = Math.max(4.4, wy + this.p.wallR - 0.3, y1 + 1.2), bBot = Math.min(-5, y0 - 0.9);
    this.box = { w: 2 * xh, top: bTop, h: bTop - bBot };   // what a panel needs to show
    this.grab = null; this.guide = 0;
    this.setDrug(Array(N).fill('P'), Array(Math.max(0, N - 2)).fill('S')); this.reset();
  }
  setPocket() { /* expert pockets are fixed: make a new sim for a different pocket */ }
  setDrug(parts, bends) {
    const N = this.slots, np = this.np; this.parts = parts.slice(); this.molBends = bends.slice();
    this.ringOf = []; let nr = 0;
    parts.forEach((t, k) => { this.type[np + k] = t === 'R' ? 'N' : t; this.sigma[np + k] = 1; if (t === 'R') { this.ringOf.push([k, np + N + nr]); nr++; } });
    this.ringOf.forEach(([k, i]) => { this.type[i] = 'R'; this.sigma[i] = RING_SIGMA; });
    this.nd = N + nr; this.n = np + this.nd;
    // where every drug bead should sit when docked
    const pr = rightNormals(this.dockPos);
    this.target = this.dockPos.map(p => p.slice());
    this.ringOf.forEach(([k]) => this.target.push([this.dockPos[k][0] + pr[k][0] * LP, this.dockPos[k][1] + pr[k][1] * LP]));
    // bonds: protein network + molecule backbone + ring stalks
    const b = this.protBonds.slice();
    for (let k = 0; k < N - 1; k++) b.push([np + k, np + k + 1, 1.08, 150]);
    this.ringOf.forEach(([k, i]) => b.push([np + k, i, LP, 150]));
    this.nb = b.length; this.bI = Int32Array.from(b, q => q[0]); this.bJ = Int32Array.from(b, q => q[1]);
    this.bR = Float64Array.from(b, q => q[2]); this.bK = Float64Array.from(b, q => q[3]);
    // angles: backbone bends, and each ring held at right angles below its part
    const ideal = withRings(buildShape(bends, N), parts), ang = [];
    const phiOf = (i0, i1, i2) => { const ax = ideal[i0][0] - ideal[i1][0], ay = ideal[i0][1] - ideal[i1][1], bx = ideal[i2][0] - ideal[i1][0], by = ideal[i2][1] - ideal[i1][1]; return Math.atan2(ax * by - ay * bx, ax * bx + ay * by); };
    for (let k = 1; k < N - 1; k++) ang.push([np + k - 1, np + k, np + k + 1, phiOf(k - 1, k, k + 1)]);
    this.ringOf.forEach(([k, i], j) => { const nb = k < N - 1 ? k + 1 : k - 1; ang.push([i, np + k, np + nb, phiOf(N + j, k, nb)]); });
    this.ang = ang; this.ideal = ideal;
    this.tab();
  }
  tab() {   // each part (or its ring) is attracted only by the spot it sits over; everything else just bumps
    const np = this.np, N = this.slots, sc = this.def.scale || XSCALE, own = this.def.own === false ? null : true;
    for (let a = 0; a < this.nd; a++) {
      const slot = a < N ? a : this.ringOf[a - N][0];
      for (let b = 0; b < np; b++) {
        const w = b < N ? this.siteW[b] : 1, sg = (this.sigma[np + a] + this.sigma[b]) / 2;
        let e = (own && b < N && b !== slot) ? 0 : pairEpsX(this.type[np + a], this.type[b]) * w * sc;
        this.eps[a * np + b] = e < 0 ? e * (this.def.bad || XBAD) : e; this.sg2[a * np + b] = sg * sg;
      }
    }
  }
  thermalise() { const s = Math.sqrt(this.p.kT); for (let i = 0; i < this.n; i++) { this.vx[i] = gauss() * s; this.vy[i] = gauss() * s; } }
  reset() {
    for (let i = 0; i < this.np; i++) { this.x[i] = this.native[i][0]; this.y[i] = this.native[i][1]; }
    for (let a = 0; a < this.nd; a++) { this.x[this.np + a] = this.target[a][0]; this.y[this.np + a] = this.target[a][1]; }
    this.thermalise(); this.forces();
  }
  dock() {   // place the designed shape where it fits best, then let it settle (a quick energy minimisation)
    const pose = alignTo(this.ideal, this.target), np = this.np;
    for (let a = 0; a < this.nd; a++) { this.x[np + a] = pose[a][0]; this.y[np + a] = pose[a][1]; this.vx[np + a] = this.vy[np + a] = 0; }
    for (let it = 0; it < 300; it++) {
      this.forces();
      for (let k = np; k < this.n; k++) { this.x[k] += Math.max(-0.03, Math.min(0.03, this.fx[k] * 0.002)); this.y[k] += Math.max(-0.03, Math.min(0.03, this.fy[k] * 0.002)); }
    }
    this.forces();
  }
  forces() {
    const { x, y, fx, fy, p, np, nd } = this; fx.fill(0); fy.fill(0);
    const bI = this.bI, bJ = this.bJ, bR = this.bR, bK = this.bK, E = this.eps, S2 = this.sg2;
    for (let q = 0; q < this.nb; q++) {
      const i = bI[q], j = bJ[q], dx = x[j] - x[i], dy = y[j] - y[i], r = Math.sqrt(dx * dx + dy * dy) || 1e-9, f = -bK[q] * (r - bR[q]) / r;
      fx[j] += f * dx; fy[j] += f * dy; fx[i] -= f * dx; fy[i] -= f * dy;
    }
    for (let i = 0; i < np; i++) { fx[i] -= p.kr * (x[i] - this.native[i][0]); fy[i] -= p.kr * (y[i] - this.native[i][1]); }
    for (const [i0, i1, i2, phi0] of this.ang) {   // signed angles keep the designed shape
      const ax = x[i0] - x[i1], ay = y[i0] - y[i1], bx = x[i2] - x[i1], by = y[i2] - y[i1];
      const c = ax * by - ay * bx, d = ax * bx + ay * by, q2 = c * c + d * d || 1e-9, phi = Math.atan2(c, d);
      const g = p.ka * Math.sin(phi - phi0);
      const pax = (d * by - c * bx) / q2, pay = (d * -bx - c * by) / q2, pbx = (d * -ay - c * ax) / q2, pby = (d * ax - c * ay) / q2;
      fx[i0] -= g * pax; fy[i0] -= g * pay; fx[i2] -= g * pbx; fy[i2] -= g * pby; fx[i1] += g * (pax + pbx); fy[i1] += g * (pay + pby);
    }
    const W = this.def.range || XRANGE;
    for (let a = 0; a < nd; a++) {   // short-ranged attraction: each part feels the spot right under it, not its neighbours'
      const ia = np + a, xa = x[ia], ya = y[ia];
      for (let b = 0; b < np; b++) {
        const k = a * np + b, s2 = S2[k], dx = x[b] - xa, dy = y[b] - ya, r2 = dx * dx + dy * dy, rmin2 = 1.2599210498948732 * s2;
        let f;
        if (r2 < rmin2) { const rc = Math.max(r2, 0.36 * s2), q = s2 / rc, s6 = q * q * q; f = 24 * (2 * s6 * s6 - s6) / rc; }
        else {
          const eps = E[k]; if (!eps) continue;
          const sg = Math.sqrt(s2), r = Math.sqrt(r2), u = (r - 1.122462 * sg) / (W * sg); if (u >= 1) continue;
          f = -eps * Math.sin(Math.PI * u) * Math.PI / (2 * W * sg) / r;
        }
        fx[b] += f * dx; fy[b] += f * dy; fx[ia] -= f * dx; fy[ia] -= f * dy;
      }
    }
    for (let a = np; a < this.n; a++) {
      const dx = x[a] - p.wallX, dy = y[a] - p.wallY, r = Math.hypot(dx, dy);
      if (r > p.wallR) { const f = -4 * (r - p.wallR) / r; fx[a] += f * dx; fy[a] += f * dy; }
    }
    if (this.guide) for (let a = 0; a < nd; a++) { const i = np + a; fx[i] += this.guide * (this.target[a][0] - x[i]); fy[i] += this.guide * (this.target[a][1] - y[i]); }
    if (this.grab) {
      const g = this.grab; let gx = 20 * (g.x - x[g.i]), gy = 20 * (g.y - y[g.i]); const m = Math.hypot(gx, gy);
      if (m > 50) { gx *= 50 / m; gy *= 50 / m; } fx[g.i] += gx; fy[g.i] += gy;
    }
  }
  step(ns) { PocketSim.prototype.step.call(this, ns); }
  rmsd() { let s = 0; for (let a = 0; a < this.nd; a++) s += (this.x[this.np + a] - this.target[a][0]) ** 2 + (this.y[this.np + a] - this.target[a][1]) ** 2; return Math.sqrt(s / this.nd); }
  worst() { let m = 0; for (let a = 0; a < this.nd; a++) m = Math.max(m, (this.x[this.np + a] - this.target[a][0]) ** 2 + (this.y[this.np + a] - this.target[a][1]) ** 2); return Math.sqrt(m); }
  bound() { return this.rmsd() < SIM.rmsdCut && this.worst() < (this.def.maxDev || XMAXDEV); }   // every part has to stay in its spot
}
if (typeof module !== 'undefined') module.exports = { GenPocketSim, pairEpsX, buildShape, dockPose, genProtein, RING_SIGMA, RES_SIGMA };
