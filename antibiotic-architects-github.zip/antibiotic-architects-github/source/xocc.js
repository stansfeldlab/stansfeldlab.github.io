// expert-pocket occupancy: loads sim.js + gensim.js into one scope
const fs = require('fs');
const strip = t => t.replace(/if \(typeof module[^\n]*\n?/g, '');
const tmpB = __dirname + '/.xbundle.' + process.pid + '.js';
fs.writeFileSync(tmpB, strip(fs.readFileSync(__dirname + '/src/sim.js', 'utf8')) + '\n' + strip(fs.readFileSync(__dirname + '/src/gensim.js', 'utf8')) +
  '\nmodule.exports={GenPocketSim,SIM,pairEpsX,dockPose,genProtein,buildShape,PocketSim};');
fs.renameSync(tmpB, __dirname + '/.xbundle.js');
const ctx = require('./.xbundle.js');
const { GenPocketSim, SIM } = ctx;
function xocc(def, mol, bends, R = 12, T = 500, opts = {}) {
  const sims = Array.from({ length: R }, () => { const s = new GenPocketSim(def); s.setDrug(mol.split(''), bends.split('')); s.reset(); s.dock(); return s; });
  const frames = Math.round(T / (160 * SIM.dt)); let inside = 0, n = 0, rs = 0;
  for (let f = 0; f < frames; f++) for (const s of sims) { s.step(160); n++; const r = s.rmsd(); rs += r; if (s.bound()) inside++; }
  return opts.detail ? { occ: Math.round(100 * inside / n), mr: rs / n } : Math.round(100 * inside / n);
}
module.exports = { xocc, ctx };
if (require.main === module) {
  const [,, defjson, mol, bends, R = 12, T = 500, reps = 1] = process.argv;
  const def = JSON.parse(defjson); const v = [];
  for (let r = 0; r < +reps; r++) v.push(xocc(def, mol, bends, +R, +T));
  console.log(`${mol}/${bends}: ${v.join(' ')}`);
}
