// occupancy of molecule(s) in pocket(s): node occ.js MOL POCKET [replicas] [tau] [repeats]
const { PocketSim, SIM } = require('./src/sim.js');
function occ(mol, pk, R, T) {
  const sims = Array.from({ length: R }, () => { const s = new PocketSim(); s.setPocket(pk.split('')); s.setDrug(mol.split('')); s.reset(); s.dock(); return s; });
  const frames = Math.round(T / (160 * SIM.dt)); let inside = 0, n = 0;
  for (let f = 0; f < frames; f++) for (const s of sims) { s.step(160); n++; if (s.bound()) inside++; }
  return Math.round(100 * inside / n);
}
if (require.main === module) {
  const [,, mol, pk, R = 8, T = 500, reps = 1] = process.argv; const v = [];
  for (let r = 0; r < +reps; r++) v.push(occ(mol, pk, +R, +T));
  console.log(`${mol} in ${pk}: ${v.join(' ')}`);
}
module.exports = { occ };
