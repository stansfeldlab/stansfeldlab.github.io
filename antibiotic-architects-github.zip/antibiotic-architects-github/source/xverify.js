// node xverify.js [shard nshard]  (env REPS, R, T): checks every expert mission's answer and the designs it should reject
const { xocc } = require('./xocc.js'), { XMISSIONS } = require('./src/xmissions.js');
const toDef = (pk, sc) => pk && { scale: sc, bends: pk.bends.split(''), sites: pk.sites.map(s => ({ t: s.t, deep: !!s.deep })) };
const CHECKS = {   // [molecule, bends, expectation]: pass = must pass, fail = must fail (bacteria, human or a rule)
  x1: [['ORO+', 'SS', 'pass'], ['OOO+', 'SS', 'fail'], ['O+O+', 'SS', 'fail'], ['OOR+', 'SS', 'fail'], ['ROO+', 'SS', 'fail']],
  x2: [['P+O+', 'SS', 'pass'], ['POO+', 'SS', 'fail'], ['PPO+', 'SS', 'fail'], ['PRO+', 'SS', 'fail']],
  x3: [['+OOO-', 'LRL', 'pass'], ['+OOO-', 'SSS', 'fail'], ['+OOO-', 'LSL', 'fail'], ['+OOO-', 'RLR', 'fail']],
  x4: [['ORO-', 'SL', 'pass'], ['OOO-', 'SL', 'fail'], ['O+O-', 'SL', 'fail'], ['ORO-', 'LS', 'fail']],
  x5: [['P+RO+', 'SLS', 'pass'], ['PPRO+', 'SLS', 'fail'], ['P+OP+', 'SLS', 'fail'], ['P+RO+', 'SSS', 'fail']]
};
const [, , sh = 0, ns = 1] = process.argv, R = +(process.env.R || 12), T = +(process.env.T || 500), reps = +(process.env.REPS || 1);
let job = 0;
for (const M of XMISSIONS) for (const [mol, b, want] of CHECKS[M.key] || []) {
  if (job++ % ns != sh) continue;
  const bb = [], hh = [];
  for (let r = 0; r < reps; r++) { bb.push(xocc(toDef(M.bact, M.scale), mol, b, R, T)); if (M.human) hh.push(xocc(toDef(M.human, M.scale), mol, b, R, T)); }
  console.log(`${M.key} ${(mol + '/' + b).padEnd(10)} ${want.padEnd(4)} bact ${bb.join(',').padEnd(14)} human ${hh.join(',') || '-'}`);
}
