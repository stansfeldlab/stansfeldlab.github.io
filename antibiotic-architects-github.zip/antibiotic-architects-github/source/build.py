"""Build the single-file game from the sources.
Usage:  python3 build.py [output.html]
Default output: Antibiotic-Architects.html in the folder above this one."""
import json, os, re, sys
B = os.path.dirname(os.path.abspath(__file__)) + '/'
OUT = sys.argv[1] if len(sys.argv) > 1 else os.path.join(B, '..', 'Antibiotic-Architects.html')
strip = lambda t: re.sub(r"if \(typeof module !== 'undefined'\) module\.exports = [^\n]*\n?", '', t)
read = lambda f: open(B + f, encoding='utf-8').read()
sim = strip(read('src/sim.js'))
cfg = json.load(open(B + 'tuning.json'))
sim = re.sub(r"const SIM = \{[^}]*\};", "const SIM = " + json.dumps(cfg['SIM']).replace('"', '') + ";", sim)
sim += '\n' + strip(read('src/gensim.js'))
table = read('table.txt').strip()
assert len(table) == 8192, 'table.txt should hold 64 x 64 x 2 digits'
missions = read('src/missions.js') + "\nconst RACE_HUMANS = " + json.dumps(cfg['RACE_HUMANS']) + ";\nconst RACE_SOLVE = " + json.dumps(cfg['RACE_SOLVE']).replace('"', '') + ";\n"
missions += strip(read('src/xmissions.js')) + "XMISSIONS.forEach(M => { M.expert = true; });\n"
game = read('src/game.js').replace('/*@@SIM@@*/', sim).replace('@@TABLE@@', table).replace('/*@@MISSIONS@@*/', missions)
assert 'module.exports' not in game
html = read('src/head.html') + read('src/body.html') + '<script>\n' + game + '</script>\n</body>\n</html>\n'
open(OUT, 'w', encoding='utf-8').write(html)
print('built', os.path.normpath(OUT), len(html), 'bytes')
